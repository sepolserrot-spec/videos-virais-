from pathlib import Path
import json,math,subprocess,wave
import numpy as np
from animar import SEND
P=Path(__file__).resolve().parents[1];O=Path('/workspace/output');M=json.loads((P/'manifest.json').read_text());D=M['duration'];sr=48000;n=round(D*sr);fx=np.zeros((n,2));rng=np.random.default_rng(401126)
def click(at,freq,gain,dur):
 k=round(at*sr);u=np.arange(min(round(dur*sr),n-k))/sr;a=np.sin(2*np.pi*freq*u)*np.exp(-u*65)*gain*(1-np.exp(-u*500));fx[k:k+len(a)]+=a[:,None]
click(SEND,740,.075,.09);click(SEND+.34,1050,.045,.12)
with wave.open(str(P/'assets/efeitos.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((fx*32700).astype('<i2').tobytes())
cmd=['ffmpeg','-y','-v','error','-i','build/animacao-muda.mp4','-i','assets/narracao.wav','-i','assets/efeitos.wav','-filter_complex','[1:a]aformat=channel_layouts=stereo,loudnorm=I=-16:TP=-1.5:LRA=8[v];[v][2:a]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-16:TP=-1.5:LRA=9[a]','-map','0:v','-map','[a]','-t',str(D),'-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-movflags','+faststart',str(O/'cartoon-mensagem.mp4')];subprocess.run(cmd,cwd=P,check=True)
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(P/'legendas.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(s["start"])} --> {stamp(s["end"])}\n{s["text"]}' for i,s in enumerate(M['subtitles']))+'\n')
M['status']='rendered';M['assets']={'character':'assets/personagem-mestre.png','arm_and_touch':'assets/braco-celular-toque.png','room':'assets/sala.png','table':'assets/mesa.png'};M['animation']='Illustrated layered cutout animation: connected phone/arm transform, head inclination, distinct concern/relief expressions, actual typing/deletion, moving tap hand and animated sending state. Not generative video or full-body motion.';M['send_action_s']=SEND;M['action_alignment']='Send action is placed near the measured end of the synthesized phrase; no claim of phoneme-level alignment.'
(P/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2));print('READY',O/'cartoon-mensagem.mp4')
