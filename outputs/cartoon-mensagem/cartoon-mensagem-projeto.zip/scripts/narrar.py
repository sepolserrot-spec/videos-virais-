from pathlib import Path
import os,json
os.environ['OMP_NUM_THREADS']='2'
import numpy as np,soundfile as sf
from kokoro_onnx import Kokoro
P=Path(__file__).resolve().parents[1]
# Short independently measured speech chunks provide real subtitle/action clocks.
scenes=[(['Essa mensagem quase ficou no rascunho.'],3.3,'hesitar'),(['Eu escrevia.','Apagava.','E esperava o momento certo.'],4.8,'rascunho'),(['Mas ninguém responde a uma mensagem','que nunca foi enviada.'],4.7,'decisao'),(['Então eu respirei.','E apertei enviar.'],3.8,'enviar'),(['O medo não sumiu.','Só deixou de decidir por mim.'],4.5,'alivio')]
k=None;sr=24000;chunks=[np.zeros(round(.1*sr))];cursor=.1;out=[];subs=[]
for i,(parts,minimum,kind) in enumerate(scenes):
 start=0 if i==0 else cursor;local=cursor;voiceparts=[]
 for j,text in enumerate(parts):
  f=P/f'assets/voz-{i}-{j}.wav'
  if f.exists():a,sr=sf.read(f)
  else:
   if k is None:k=Kokoro('/workspace/tts-kokoro/models/kokoro-v1.0.onnx','/workspace/tts-kokoro/models/voices-v1.0.bin')
   a,sr=k.create(text,voice='pm_alex',lang='pt-br',speed=1.0);sf.write(f,a,sr)
  gap=.16 if j<len(parts)-1 else .24
  subs.append({'scene':i,'start':cursor,'end':cursor+len(a)/sr,'text':text});voiceparts.append({'start':cursor,'end':cursor+len(a)/sr,'text':text});chunks.extend([a,np.zeros(round(gap*sr))]);cursor+=len(a)/sr+gap
 extra=max(0,minimum-(cursor-start));chunks.append(np.zeros(round(extra*sr)));cursor+=extra
 out.append({'id':i,'kind':kind,'start':start,'end':cursor,'duration':cursor-start,'voice_parts':voiceparts});print(i,round(cursor-start,2),kind,flush=True)
a=np.concatenate(chunks);sf.write(P/'assets/narracao.wav',a,sr)
m={'title':'A mensagem no rascunho','version':4,'skill':'stickman-video-pro revisão 2','duration':len(a)/sr,'format':{'w':1080,'h':1920,'fps':30},'voice':{'engine':'Kokoro ONNX','preset':'pm_alex','lang':'pt-br','license':'Apache-2.0'},'scenes':out,'subtitles':subs,'music':False,'status':'voice_ready','reference_access':'YouTube blocked by network; art direction based on supplied skill description, not direct visual comparison.'}
(P/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print('duration',len(a)/sr)
