"""Illustrated cutout animation, distinct camera setups and a real phone-send state change."""
from pathlib import Path
import math,json,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps
P=Path(__file__).resolve().parents[1];M=json.loads((P/'manifest.json').read_text());W,H,FPS=1080,1920,30;D=M['duration'];SC=M['scenes'];RED='#9b363e';INK='#322c2a';CREAM='#fff7e8';F={}
def font(size,bold=False):
 key=(size,bold)
 if key not in F:F[key]=ImageFont.truetype(str(P/'assets'/('Text-Bold.ttf' if bold else 'Text.ttf')),size)
 return F[key]
def ease(x):x=max(0,min(1,x));return x*x*(3-2*x)
def mix(a,b,u):return np.array(a)*(1-u)+np.array(b)*u
master=Image.open(P/'assets/personagem-mestre.png').convert('RGBA');phoneatlas=Image.open(P/'assets/braco-celular-toque.png').convert('RGBA')
def trim(rect):
 im=master.crop(rect);box=im.getchannel('A').point(lambda a:255 if a>100 else 0).getbbox();return im.crop(box)
HEAD=trim((20,0,610,515));SMILE=trim((640,0,1254,515));BODY=trim((40,520,570,1254));FINGER=phoneatlas.crop((140,820,1024,1536))
BGS={k:ImageOps.fit(Image.open(P/f'assets/{k}.png').convert('RGB'),(W,H),method=Image.Resampling.LANCZOS) for k in ['sala','mesa']}
FULL='Oi! Posso te mostrar uma ideia?'

def wrap(text,f,width):
 out=[];line=''
 for word in text.split():
  cand=(line+' '+word).strip()
  if f.getlength(cand)>width and line:out.append(line);line=word
  else:line=cand
 if line:out.append(line)
 return out

def current_scene(t):return max(i for i,s in enumerate(SC) if t>=s['start'])
SEND=SC[3]['voice_parts'][1]['end']-.25

def typed(t,i):
 if t>=SEND:return FULL
 if i==0:return FULL[:3]
 if i==1:
  p0,p1,p2=SC[1]['voice_parts']
  if t<p1['start']:return FULL[:3+round((len(FULL)-3)*ease((t-p0['start'])/(p0['end']-p0['start'])))]
  if t<p2['start']:return FULL[:3+round((len(FULL)-3)*(1-ease((t-p1['start'])/(p1['end']-p1['start']))))]
  return FULL[:3+round((len(FULL)-3)*ease((t-p2['start'])/(p2['end']-p2['start'])))]
 return FULL

def phone_asset(t,i):
 im=phoneatlas.crop((0,0,1024,750)).copy();screen=Image.new('RGBA',(210,380),CREAM);d=ImageDraw.Draw(screen)
 d.rectangle((0,0,210,46),fill='#f0e2cb');d.text((17,18),'Conversa',font=font(16,True),fill=INK,anchor='lm');d.line((0,46,210,46),fill='#d1baa2',width=1)
 d.text((105,73),'Hoje',font=font(10),fill='#8d786b',anchor='mm')
 sent=ease((t-SEND)/.32) if t>=SEND else 0
 if sent>0:
  # The exact drafted message moves from the composer into the conversation.
  y=int(203*(1-sent)+100*sent);d.rounded_rectangle((17,y,195,y+92),radius=12,fill='#ead0cc')
  for n,line in enumerate(wrap(FULL,font(13),155)):d.text((29,y+12+n*18),line,font=font(13),fill=INK)
  if sent>.96:
   d.text((95,y+78),'Enviada',font=font(9),fill=RED);d.text((157,y+77),'✓',font=font(12),fill=RED);d.text((184,y+77),'✓',font=font(12),fill=RED)
 text='' if sent else typed(t,i)
 d.rounded_rectangle((9,218,201,281),radius=12,fill='#fffdf7',outline='#cdb6a0',width=1)
 for n,line in enumerate(wrap(text,font(12),143)[:3]):d.text((18,226+n*15),line,font=font(12),fill=INK)
 if not sent and int(t*2.4)%2==0:
  lines=wrap(text,font(12),143) or [''];ln=lines[-1];cx=18+font(12).getlength(ln);cy=226+(len(lines)-1)*15;d.line((cx,cy,cx,cy+13),fill=RED,width=1)
 bx,by=183,253;pulse=.0
 if SEND-.05<t<SEND+.15:pulse=.4*math.sin(math.pi*(t-SEND+.05)/.20)
 r=16+3*pulse;d.ellipse((bx-r,by-r,bx+r,by+r),fill='#b59c95' if sent>.96 else RED)
 d.polygon([(bx-5,by-7),(bx+8,by),(bx-5,by+7),(bx-2,by)],fill=CREAM)
 d.rectangle((0,292,210,380),fill='#e1d3c2')
 for row,letters in enumerate(['QWERTYUIOP','ASDFGHJKL','ZXCVBNM']):
  cell=19;offset=(210-len(letters)*cell)/2
  for j,char in enumerate(letters):
   x=offset+j*cell;y=299+row*24;active=not sent and i==1 and int(t*7)%len(letters)==j
   d.rounded_rectangle((x,y,x+16,y+20),radius=3,fill='#bf9d93' if active else '#fff7eb');d.text((x+8,y+9),char,font=font(9),fill=INK,anchor='mm')
 d.rounded_rectangle((48,372,161,377),radius=2,fill='#b5a397')
 # Screen art stays inside the illustrated phone bezel.
 screen.putalpha(Image.new('L',screen.size,255));im.alpha_composite(screen,(697,76));return im

def paste_pivot(canvas,asset,pivot,dest,scale=1,angle=0):
 rad=math.radians(angle);co=math.cos(rad);si=math.sin(rad);dx,dy=dest;px,py=pivot
 corners=[(dx+scale*(co*(x-px)-si*(y-py)),dy+scale*(si*(x-px)+co*(y-py))) for x,y in [(0,0),(asset.width,0),(asset.width,asset.height),(0,asset.height)]]
 x0=max(0,math.floor(min(x for x,y in corners))-2);y0=max(0,math.floor(min(y for x,y in corners))-2);x1=min(W,math.ceil(max(x for x,y in corners))+2);y1=min(H,math.ceil(max(y for x,y in corners))+2)
 if x1<=x0 or y1<=y0:return
 c=co/scale;s=si/scale
 coeff=(c,s,px-c*dx-s*dy+c*x0+s*y0,-s,c,py+s*dx-c*dy-s*x0+c*y0)
 layer=asset.transform((x1-x0,y1-y0),Image.Transform.AFFINE,coeff,resample=Image.Resampling.BICUBIC)
 canvas.alpha_composite(layer,(x0,y0))

def hero(t,i):
 im=BGS['sala'].convert('RGBA');local=t-SC[i]['start'];relax=ease((t-SC[4]['start'])/.8) if i==4 else 0
 close=i==2;breath=math.sin(t*1.6)*3
 # Illustrated torso, face and arm are independent layers; no geometric substitute body.
 bx,by=(65,665) if not close else (-5,750);bw=620 if not close else 710
 body=BODY.resize((bw,round(BODY.height*bw/BODY.width)),Image.Resampling.LANCZOS);im.alpha_composite(body,(bx,round(by+breath)))
 hwidth=590 if not close else 745;ha=SMILE if i==4 else HEAD
 head=ha.resize((hwidth,round(ha.height*hwidth/ha.width)),Image.Resampling.LANCZOS)
 hx,hy=(130,112) if not close else (45,76);tilt=(-3+2*math.sin(local*.8)) if i!=4 else 2-3*relax
 paste_pivot(im,head,(head.width*.46,head.height*.86),(hx+head.width*.46,hy+head.height*.86+breath),1,tilt)
 arm=phone_asset(t,i);anchor=(230,720+breath) if not close else (290,900+breath);angle=-2*math.sin(local*1.0)+5*relax
 paste_pivot(im,arm,(130,210),(anchor[0],anchor[1]+70*relax),.72 if not close else .76,angle)
 return im

def detail(t,i):
 im=BGS['mesa'].convert('RGBA');art=phone_asset(t,i).crop((560,0,1000,600))
 # The close-up gives the message and send button a readable role in the story.
 scale=2.35;dest=(32,90);paste_pivot(im,art,(0,0),dest,scale,0)
 button=np.array([dest[0]+(697+183-560)*scale,dest[1]+(76+253)*scale])
 if i==1:
  phase=(t-SC[1]['start'])*2.3;tip=button+np.array([-100+25*math.sin(phase),190+8*math.sin(phase*2)])
  # Writing/erasing appears on screen while the hand works in the keyboard region.
  paste_pivot(im,FINGER,(59,63),tuple(tip),1.03,0)
 if i==3:
  dt=t-SEND
  if dt<-.55:tip=button+np.array([155,185])
  elif dt<0:tip=button+np.array([155,185])*(1-ease((dt+.55)/.55))
  elif dt<.13:tip=button+np.array([-2,2])*math.sin(math.pi*dt/.13)
  else:tip=button+np.array([180,230])*ease((dt-.13)/.5)
  paste_pivot(im,FINGER,(59,63),tuple(tip),1.03,0)
 return im

CAPTION_LINES={
'Essa mensagem quase ficou no rascunho.':['Essa mensagem quase','ficou no rascunho.'],
'Eu escrevia.':['Eu escrevia.'], 'Apagava.':['Apagava.'], 'E esperava o momento certo.':['E esperava','o momento certo.'],
'Mas ninguém responde a uma mensagem':['Mas ninguém responde','a uma mensagem'], 'que nunca foi enviada.':['que nunca foi enviada.'],
'Então eu respirei.':['Então eu respirei.'], 'E apertei enviar.':['E apertei enviar.'],
'O medo não sumiu.':['O medo não sumiu.'], 'Só deixou de decidir por mim.':['Só deixou de decidir','por mim.']}

def caption(im,t):
 subs=[s for s in M['subtitles'] if s['start']<=t<s['end']+.12]
 if not subs:return im
 sub=subs[-1];lines=CAPTION_LINES[sub['text']];layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
 # One legible caption region; no simultaneous slogan, title or CTA.
 box=(54,1500,1026,1740 if len(lines)>1 else 1675);d.rounded_rectangle(box,radius=26,fill=(255,247,233,239),outline=(80,49,39,45),width=2)
 fs=59
 while any(font(fs,True).getlength(l)>900 for l in lines):fs-=1
 for n,line in enumerate(lines):d.text((540,1562+n*83),line,font=font(fs,True),fill=RED if n==len(lines)-1 else INK,anchor='mm')
 im.alpha_composite(layer);return im

def frame(t):
 i=current_scene(t);im=detail(t,i) if i in [1,3] else hero(t,i)
 return caption(im,t).convert('RGB')

if __name__=='__main__':
 if '--frames' in sys.argv:
  for i,s in enumerate(SC):
   for label,at in [('inicio',s['start']+.35),('meio',s['start']+s['duration']*.55),('fim',s['end']-.35)]:frame(at).save(P/f'qc/cena-{i}-{label}.png')
  frame(SEND).save(P/'qc/contato-envio.png');print('frames ready');raise SystemExit()
 start=SEND-1.2 if '--test' in sys.argv else 0;duration=3 if '--test' in sys.argv else D;output=P/('build/teste-envio.mp4' if '--test' in sys.argv else 'build/animacao-muda.mp4')
 proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(output)],stdin=subprocess.PIPE)
 for n in range(math.ceil(duration*FPS)):
  proc.stdin.write(frame(min(start+n/FPS,D-.001)).tobytes())
  if n%90==0:print(f'{n/FPS:.1f}/{duration:.1f}s',flush=True)
 proc.stdin.close();assert proc.wait()==0;print('READY',output)
