from pathlib import Path
import json,subprocess,sys,math
import numpy as np
from PIL import Image,ImageDraw
from animar import SEND,SC
P=Path(__file__).resolve().parents[1];V=Path('/workspace/output/cartoon-mensagem.mp4');M=json.loads((P/'manifest.json').read_text())
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True)
d=json.loads(run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(V)]).stdout);v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio');dur=float(d['format']['duration'])
assert abs(dur-M['duration'])<.05;assert(v['width'],v['height'],v['pix_fmt'])==(1080,1920,'yuv420p');assert a['sample_rate']=='48000' and a['channels']==2
r=run(['ffmpeg','-hide_banner','-i',str(V),'-vf','blackdetect=d=0.2:pix_th=0.05','-af','silencedetect=n=-50dB:d=3,loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);(P/'qc/decode-audio.log').write_text(r.stderr);assert 'black_start:' not in r.stderr;assert 'silence_start:' not in r.stderr
sys.path.insert(0,'/workspace/videos-virais-/.agents/skills/video-viral');import desmontar as kit
# Uniform export samples plus the real send contact, transition and end state.
times=sorted(set([round(i*.5,3) for i in range(math.ceil(dur/.5)) if i*.5<dur]+[round(SEND-.12,3),round(SEND,3),round(SEND+.2,3),round(SEND+.6,3),round(dur-.2,3)]))
for part in range(math.ceil(len(times)/15)):
 ts=times[part*15:(part+1)*15];kit.folha([kit.quadro(V,t,180) for t in ts],[f'{t:.2f}s' for t in ts],5,P/f'qc/exportacao-{part+1}.jpg')
hero=[s['start']+s['duration']*.55 for s in M['scenes']];kit.folha([kit.quadro(V,t,270) for t in hero],[f'{t:.1f}s' for t in hero],3,P/'qc/historia.jpg')
# Screen state visibly changes around the touch, independently of a camera move.
f1=np.asarray(kit.quadro(V,SEND-.12,270))[65:280,90:230];f2=np.asarray(kit.quadro(V,SEND+.6,270))[65:280,90:230];change=float((np.max(np.abs(f1.astype(float)-f2.astype(float)),axis=2)>18).mean());assert change>.04,change
report={'duration_s':dur,'resolution':[1080,1920],'fps':v['r_frame_rate'],'audio_codec':a['codec_name'],'integrated_lufs':kit.volume(V),'decode_ok':True,'unexpected_black_frames':False,'silence_over_3s':False,'frame_samples':times,'send_action':{'time_s':SEND,'screen_changed_fraction':change},'art_direction':'Original painted cartoon with shared master character, two illustrated environments and separate arm/phone/tap assets. Layered cutout animation, not a geometric avatar or photographic slideshow.','reference_limit':'YouTube blocked; direct style/acting comparison not possible. Direction follows the uploaded skill description.','review_limit':'Exported frames sampled, critical contact and sending states examined. No auditory review or claim of full-playback fluency; measured audio and sentence timings only.','bytes':int(d['format']['size'])}
(P/'qc/report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));M['status']='validated_technical';(P/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
