---
name: stickman-video-pro
description: Analisa referências e produz vídeos stickman ou cartoon ilustrado para Reels, TikTok e Shorts, com personagem consistente, imagens próprias por cena, animação, voz e montagem verificadas. Use para "bonecos de palito", "igual à referência", "stickman com IA" ou corrigir um vídeo stickman fraco. O desenho segue a referência, não um esqueleto geométrico obrigatório. Não promete viralização.
---

# Stickman Video Pro

## Resultado esperado

Entregue uma pequena história visual original, compreensível e expressiva, no estilo stickman/cartoon realmente pedido, com narração quando solicitada e acabamento verificado. O espectador deve perceber ação, mudança e conclusão; não apenas frases motivacionais sobre imagens repetidas. Esta é a revisão 2: prioriza fidelidade de direção de arte e produção de cenas, não apenas mais movimento em um boneco simples.

Esta skill orienta direção e qualidade. Não fornece por si só motores de vídeo, vozes, credenciais ou garantias de alcance. Descubra ferramentas reais antes de prometer uma produção. Criar a skill não equivale a produzir um vídeo.

## Padrão do usuário

O usuário rejeitou dois resultados: um personagem genérico no computador e um esqueleto de linhas movimentando peças no mesmo plano por cerca de 21 segundos. O problema não se resolve mudando a cor do fundo ou adicionando legendas.

A referência agora identificada é o tutorial https://www.youtube.com/watch?v=W1yazDqET7s . Seus exemplos mostram **cartoon 2D ilustrado de proporções simplificadas, cabeça expressiva, cabelo, roupa, mãos/pés e contexto de cena**, além de diagramas com bonecos de linhas usados para explicar o tutorial. Não confunda esses diagramas de apresentação com o estilo do vídeo demonstrado. Leia [references/referencia-e-falhas.md](references/referencia-e-falhas.md) antes da primeira produção deste usuário ou ao corrigir uma repetição desses defeitos.

Se não houver nova referência nem orientação diferente, use como padrão **cartoon ilustrado expressivo inspirado nos princípios observados**, com personagem original. Boneco estritamente geométrico só quando o usuário ou uma referência válida pedir esse acabamento. Não copie aparência, identidade, marca ou roteiro do criador.

Padrão ajustável: vertical 9:16, 1080 × 1920, 30 fps, aproximadamente 15–30 segundos, composição limpa, uma cor de destaque e texto em português brasileiro quando destinado ao público da Caminhos Digitais. Use o tema e a duração pedidos acima desses padrões. Não adicione propaganda ou CTA comercial se o objetivo for apenas conteúdo editorial.

Publicação hoje exige reduzir complexidade e quantidade de cenas, não abandonar revisão. Não publique ou envie a terceiros sem pedido explícito.

## 1. Entender e escolher o caminho

- Identifique ideia, público, mensagem central e objetivo: entretenimento, explicação, identificação ou oferta. Use o contexto disponível; não repita perguntas já respondidas.
- Se houver referência, abra-a e examine gancho, ações, estilo dos bonecos, enquadramento, ritmo, transições, texto e som. Se for tutorial, separe o que é vinheta, explicação, interface de ferramenta e exemplo do resultado desejado. Observe vários momentos relevantes, não apenas título e miniatura. Registre observações e limites. Reaproveite princípios e ritmo com história e recursos próprios; não copie automaticamente fala, cenas, música ou identidade.
- Se a referência estiver inacessível, informe em uma frase e avance com o padrão acima quando o usuário já autorizou. Não diga que seguiu uma referência que não viu.
- Descubra os recursos disponíveis de voz, imagens, animação e montagem. Escolha pela adequação e controle, não pelo número de ferramentas. Não gere imagens, voz ou vídeo desnecessários só porque existem ferramentas.
- Escolha o fluxo pela aparência necessária: para este padrão ilustrado, prefira personagem de referência + imagens próprias por cena + animação dos trechos + montagem. Use ferramentas de imagem/vídeo disponíveis e suas skills específicas, lendo-as antes de usar. Vetores, HyperFrames/GSAP, Remotion ou equivalentes podem montar, legendar, animar recursos adequados ou produzir o visual quando conseguirem reproduzir seu nível de acabamento. Não substitua ilustração por círculos e segmentos só porque é mais fácil programar. A tecnologia não é a direção de arte.
- Use a autorização existente para produzir e revisar; não exija aprovação de cada cena. Só pergunte se a informação ausente muda materialmente o resultado. Operações com cobrança exigem autorização aplicável; não trate prazo curto como autorização ilimitada de créditos.

## 2. Firmar a direção de arte antes de renderizar

Registre um contrato visual curto: tipo de personagem, rosto/cabelo/roupa, traço e sombreado, paleta, densidade do cenário, enquadramentos, movimento e texto. Para cada aspecto, indique o que observou na referência e como vai adaptá-lo. Aspectos inacessíveis ficam “não verificados”, não inventados.

Crie um quadro de estilo e um trecho curto representativo do maior risco antes de produzir tudo. Compare-os com a referência: o resultado pertence à mesma família visual? O protagonista tem presença e legibilidade no celular? A cena comunica a ação sem depender de um parágrafo? Faça essa verificação e avance autonomamente dentro da autorização existente. Não é uma nova aprovação obrigatória do usuário.

Se o teste não alcançar a linguagem pedida, mude o método ou recurso antes da produção completa. Não tente compensar um visual errado com resolução alta, voz melhor, mais efeitos ou uma autodeclaração de “premium”. Se faltar acesso ao gerador necessário, informe a dependência; não disfarce um substituto inferior como equivalente.

## 3. Desenvolver a ideia e produzir cenas

Defina uma frase central e uma situação concreta que a demonstre. Estruture livremente **gancho visual → problema/contraste → tentativa ou virada → consequência/recompensa**. O número de cenas deve servir à história, não a uma quota.

O primeiro segundo precisa apresentar algo legível e interessante: conflito, ação incompleta, contraste ou pergunta visual. Não comece com logotipo, tela vazia ou introdução genérica. Uma frase impactante sem ação correspondente não basta.

Crie um storyboard curto por trecho com tempo estimado, fala, ação observável, personagem/emoção, enquadramento, cenário/objetos, texto e som. Cada trecho deve responder: **o que muda na imagem e por que isso ajuda a entender a ideia?** Se só muda a legenda ou o ângulo do braço, reescreva a cena.

Produza imagens de cena com continuidade de personagem e cenário pertinente. Use enquadramentos diferentes quando a história pedir: detalhe do obstáculo, reação, ação e resultado, não apenas corpo inteiro sempre centralizado. Identifique imagens e clipes por cena e mantenha rastreável a ligação roteiro → imagem → animação → fala.

Para cada imagem, escreva um prompt com identidade visual fixa, ação concreta, expressão, objeto relevante, composição e espaço de legenda. Use o mesmo recurso de referência de personagem quando a ferramenta permitir; repetir uma descrição textual não garante consistência.

Para cada animação, separe movimento do personagem, objeto, câmera e estado final. Gere um acontecimento específico, por exemplo pegar, hesitar, testar, falhar, reagir e tentar diferente — não uma lista simultânea de ações difíceis. Especifique o que precisa permanecer estável. Verifique o clipe e sua passagem ao próximo. Não apresente pan/zoom em imagem estática como atuação corporal quando a cena exige atuação.

Uma mesma imagem pode sustentar uma ação deliberadamente contínua. Não force cenários novos a cada segundo, mas também não use o mesmo plano como preenchimento de todo o vídeo. Em um curta, procure mudanças de informação e de intenção perceptíveis; duração exata e quantidade de cortes dependem da fala e da ação.

Não reutilize automaticamente o tema “aprovação/aplausos/fazer uma tarefa” dos vídeos rejeitados ou os exemplos desta skill. Se a referência ensina um método, extraia o método e aplique ao tema atual. Escolha objetos e acontecimentos próprios: uma mensagem adiada, uma decisão diante de duas opções ou uma pequena ação que muda um resultado. São possibilidades de encenação, não roteiros obrigatórios.

Quando houver produção autorizada, mostre apenas um resumo curto e continue. Preserve roteiro já aprovado, salvo ajustes necessários explicitados.

## 4. Construir personagens e movimento com intenção

- Silhueta e acabamento conforme o contrato visual: rosto/cabelo, roupa e extremidades quando a referência ilustrada os exigir; linhas mínimas somente no estilo que pedir isso. Preserve identidade, traço, escala e anatomia. Não retire expressão facial por seguir uma definição literal de “boneco de palito”.
- Mantenha proporções, comprimento de membros e pontos de articulação consistentes. Animar uma pose não deve fazer nascer membros ou trocar conexão de articulações.
- Defina poses-chave claras e trajetória do movimento. Use antecipação, ação e acomodação quando úteis, com pausas que permitam compreender o gesto. Não balance partes do corpo aleatoriamente para simular vida.
- Ao andar, pés precisam ter contato convincente e deslocamento coerente. Ao pegar um objeto, mão e objeto devem se encontrar; o objeto não deve atravessar corpo ou teletransportar sem intenção narrativa.
- Evite movimentos corporais complexos se não houver rig ou ferramenta capaz. Uma ação curta e bem executada vale mais que deformações constantes. Simplifique a ação ou divida-a em planos sem abandonar o acabamento visual combinado. Não transforme “simplificar” em reduzir toda a produção a um boneco geométrico parado.
- Encene emoções por postura, distância, reação e tempo, não apenas por emojis ou texto. Humor e exagero são opcionais e devem ser compreensíveis.
- Preserve continuidade espacial e visual entre cenas. Cortes e mudanças de escala devem ajudar a ação; não faça cortes rápidos sem motivo nem mantenha uma imagem sem função por tempo excessivo.

## 5. Voz, legendas e som

Leia [references/producao-e-verificacao.md](references/producao-e-verificacao.md) antes de montar voz/legendas e antes da entrega final.

Se houver narração, use voz real disponível e apropriada ao público, com dicção e intenção. Não clone voz de referência sem autorização. Se o usuário já escolheu uma voz, preserve-a. Gere uma amostra curta antes de uma narração longa quando houver risco de pronúncia ou estilo inadequado.

Use a duração e os eventos da fala real para ajustar as cenas. Não sincronize legendas apenas dividindo duração total por número de frases. Preserve fonte de texto e tempos; legenda deve acompanhar o que é dito. Texto de ênfase é um recurso separado, não precisa repetir cada palavra.

Música e efeitos são opcionais. Use apenas material autorizado, com volume que preserve a fala; silêncio intencional pode funcionar. Neste fluxo, o usuário escolhe música na publicação: por padrão não acrescente trilha musical, salvo pedido diferente. Isso não cancela narração solicitada nem efeitos pertinentes. Não adicione trilha genérica para esconder uma direção fraca.

## 6. Verificar o vídeo real e corrigir

Examine a exportação final, não apenas código, storyboard ou prévia do editor. Verifique começo, transições, movimento, final, áudio e legendas. Ouça quando houver reprodução de áudio disponível. Se só puder analisar quadros ou transcrição, declare esse limite e não aprove a qualidade sonora como se tivesse ouvido.

Há duas verificações distintas: **técnica** (arquivo abre, dimensões, áudio, sincronização, texto e movimentos sem defeitos) e **criativa** (gancho, compreensão, progressão, recompensa e pertinência à referência). Passar em uma não prova a outra.

Faça também a verificação comparativa: coloque lado a lado um quadro representativo do resultado e um quadro pertinente da referência para conferir direção de arte; compare trechos para atuação e ritmo. Não compare com a interface ou vinheta do tutorial por engano. Registre o que foi preservado, adaptado e não verificado. Uma imagem comparativa pode sustentar estilo, mas não prova fluidez.

Critério de compreensão: sem as legendas, ainda é possível perceber o que o personagem tenta fazer, o obstáculo e a mudança final? A fala pode explicar uma ideia abstrata, mas a ação central não pode ser indecifrável. Se forem necessários rótulos longos para entender objetos genéricos, redesenhe a cena.

Corrija problemas observados e renderize novamente os trechos afetados. Priorize no máximo duas rodadas completas de revisão por padrão; se permanecer um defeito importante, simplifique a cena em vez de regenerar indefinidamente. Não imponha gastos adicionais sem autorização. Limite de tempo ou recursos não transforma defeito em qualidade aprovada.

Não entregue como “final pronto” quando houver deformação evidente, texto cortado, áudio ausente quando solicitado, palavra errada ou cena sem conclusão. Entregue o estado real e o bloqueio específico se não puder resolver.

## Entrega

Entregue o MP4 quando a produção foi pedida, projeto editável/roteiro/tempos necessários à reutilização e uma nota curta do que foi verificado. Para uma revisão, entregue os problemas observados com tempos aproximados ou exatos conforme a evidência, sem modificar o original por suposição.

Não crie relatórios extensos se o usuário precisa publicar hoje. Explique apenas mudanças relevantes e limitações. Nunca afirme “vai viralizar”, percentuais de sucesso ou retenção medida sem dados. Diga qual decisão criativa foi usada para favorecer compreensão e atenção, como hipótese editorial.
