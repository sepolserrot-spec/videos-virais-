# Referência e falhas que motivaram a revisão 2

## Fonte e limites de observação

Referência fornecida: [Como Fazer Vídeos de Boneco de Palito com IA — VITOR VIVER DO DIGITAL](https://www.youtube.com/watch?v=W1yazDqET7s).

Inspeção em 06/11/2026: descrição expandida da página e quadros amostrados do vídeo de aproximadamente 14min47s. A descrição enumera ideia, roteiro/narração, divisão em cenas, prompts de imagem e animação, consistência de personagem, geração/animação e montagem no CapCut. Não se obteve transcrição utilizável nem audição verificada; não citar supostas instruções faladas palavra por palavra.

O tutorial alterna diagramas com bonecos lineares, interfaces de ferramentas e exemplos de personagens ilustrados. A evidência visual dos exemplos inclui cabeça grande com cabelo preto, rosto expressivo, roupa, mãos/pés e objetos/cenários. Isso não obriga a copiar cabelo ou roupa: o que se deve preservar é a categoria e o acabamento do desenho, com identidade própria.

Marcos aproximados para inspecionar novamente quando possível:
- Início: exemplos de canais e apresentação do processo; não confundir métricas mostradas com prova de resultados reproduzíveis.
- Aproximadamente 1min15s: apresentação de exemplo vertical com personagem ilustrado.
- Aproximadamente 2–5min: elaboração de roteiro e prompts/perfil de personagem visíveis em tela; texto pequeno nem sempre legível na amostragem.
- Aproximadamente 6–11min: interfaces e imagens de personagem sentado e em pé, com expressões e objetos; construção de recursos e trechos.
- Aproximadamente 11min45s–13min15s: montagem em timeline no CapCut.

Esses tempos orientam busca, não representam uma transcrição integral nem comprovam que todos os movimentos foram vistos. CapCut é uma ferramenta demonstrada, não dependência obrigatória. Pode-se montar em outra ferramenta com controle equivalente.

## Comparação com o arquivo rejeitado

Arquivo do usuário: `stickman-pro.mp4`, cerca de 21,1s, vertical 1080 × 1920, 30 fps, com stream de áudio. Imagens amostradas a cada 0,5s; não houve audição verificada. O arquivo não é evidência de quais ferramentas ou fontes o produtor utilizou: não afirmar que não usou geração de imagens só pela aparência.

| Trecho aproximado | Observação | Falha de direção | Correção operacional |
|---|---|---|---|
| 0–4,5s | Boneco de segmentos, corações e peças/colunas, texto longo; pouca mudança de enquadramento | Aprovação e tarefa são representadas por sinais pouco contextualizados, sem situar uma situação reconhecível | Mostrar uma ação concreta em contexto e um obstáculo visível; quadro de estilo ilustrado antes de renderizar |
| 4,5–8s | Legenda muda para parar de procurar aplausos; os corações desaparecem e o mesmo plano continua | Mudança emocional depende principalmente do texto | Encadear reação e decisão com enquadramento/atuação pertinentes |
| 8–16,5s | Boneco move uma peça entre suportes; “tentei/errei/ajustei/terminei” | Estados visuais parecidos; sentido da tarefa e da correção pouco explícito | Definir objeto reconhecível, tentativa, erro e mudança causal concreta; separar planos se necessário |
| 16,5–21,1s | Estrutura horizontal pronta e gesto de celebração, mesma composição geral | Há conclusão literal, mas recompensa pouco clara e sem forte demonstração da transformação | Tornar o resultado reconhecível e conectar ao conflito inicial; não depender de slogan final |

O fundo claro ou o desenho mínimo não são erros universais. Aqui, o problema é a diferença entre a família visual desejada e o resultado, somada à pouca clareza da ação. Uma animação minimalista bem dirigida pode funcionar em outro pedido.

## Pipeline obrigatório por resultado, não por marca de ferramenta

1. Contrato visual da referência pertinente.
2. Personagem mestre original, com aparência estável e expressões relevantes.
3. Roteiro com acontecimentos concretos e storyboard de cenas.
4. Imagem própria de cada cena necessária, coerente com a identidade mestre.
5. Prompt de movimento específico e clipe verificado por trecho, ou animação de recursos equivalentes com o mesmo acabamento.
6. Narração real e montagem guiada pela duração da fala, com legendas legíveis.
7. Comparação de estilo, compreensão sem legendas e revisão técnica da exportação.

Não adicionar dezenas de ferramentas por ritual. Não trocar esse pipeline por “desenhar um boneco em SVG, mover os braços e colocar texto” quando a referência pede cenas ilustradas. Se um motor vetorial produzir legitimamente o desenho, atuação e cenários requeridos, ele continua válido.

## Testes de decisão da revisão

- Pedido “faz nesse tutorial”, com diagramas lineares e personagens ilustrados: identificar o exemplo de resultado; não escolher o estilo da vinheta por conveniência.
- Pedido de cartoon ilustrado, só renderizador SVG disponível: informar o limite ou produzir recursos equivalentes com qualidade demonstrável; não alegar equivalência de um protótipo geométrico.
- Dois vídeos só diferem no braço e na legenda: revisar ação/câmera/consequência, em vez de adicionar efeitos de texto.
- Referência nova exige linhas puras: seguir a nova referência; não impor cabelo e roupa como padrão universal.
- Sem ferramenta para ouvir: não avaliar voz como natural com base em amplitude ou transcrição.

Estes são casos editoriais de avaliação, não execução independente de um novo vídeo. A skill foi corrigida; a próxima produção precisa demonstrar na prática que os critérios foram satisfeitos.
