# Produção e controle de qualidade

## Composição e recursos

Use recursos que existam e possam ser usados. Guarde fontes e decisões suficientes para remontar o vídeo; não deixe o projeto depender de um arquivo temporário desaparecido. Preserve o original em edições.

Teste um trecho curto com o personagem em movimento e texto antes de renderizar tudo. Esse teste deve verificar o risco real da produção: articulações, contato com objetos, fonte, contraste ou sincronização. Não crie uma burocracia de aprovação se o usuário já autorizou o resultado.

Antes desse teste, confirme que o personagem e o desenho pertencem à família visual pedida. Um rig articulado correto não compensa direção de arte errada. Para cartoon ilustrado, confira rosto, silhueta, roupa, acabamento e relação com o cenário. Identidade consistente não significa reutilizar exatamente a mesma imagem em todas as cenas.

No storyboard, registre os estados inicial e final dos objetos relevantes. Se uma peça muda de lugar, o espectador deve perceber como e por quê. Prefira objetos reconhecíveis ou uma demonstração suficientemente contextualizada a metáforas geométricas que exigem explicação textual contínua.

O cenário deve apoiar a ação. Fundo limpo ou cenário mínimo costuma facilitar leitura; não obriga fundo branco ou preto. Personagem principal e objeto relevante precisam ser grandes o bastante no celular. Verifique no tamanho reduzido, não só no monitor em resolução integral.

Reserve áreas para interfaces das redes, especialmente bordas inferior e direita. Não declare uma margem universal como garantia para todas as plataformas: confira a composição com a sobreposição pertinente quando disponível. Posicione legendas de forma que não cubram rosto, mãos ou objeto essencial.

## Narração e tempo

- Escreva para fala: frases com ritmo, palavras concretas e pausas úteis. Remova aberturas vazias.
- Faça a fala caber naturalmente na duração. Se não couber, corte texto ou ajuste a duração dentro do pedido, em vez de acelerar até perder expressão.
- Ouça a narração quando possível: pronúncia, respiração, entonação, cortes e fadiga sonora. Medição de amplitude não comprova voz natural.
- Determine marcações pela fala gerada: alinhamento/transcrição com tempos quando disponível ou revisão manual de trechos. Não invente precisão de milissegundos sem medição.
- Em cada frase, conecte ação e palavra importante. Nem toda sílaba exige efeito ou corte.
- Use legendas curtas com quebras por sentido; duas linhas são um bom ponto de partida, não regra absoluta. Evite fragmentos rápidos demais para ler e frases pequenas demais na tela.
- Não mantenha palavra quase invisível por contraste ruim. Se houver entrada animada, a palavra precisa se tornar legível no momento apropriado e permanecer o suficiente.
- Não sobreponha legenda completa, título, CTA e ênfase disputando a mesma área.

## Checklist da exportação

| Verificação | Evidência necessária |
|---|---|
| Arquivo íntegro | Abrir e decodificar o MP4 final; verificar duração e streams |
| Formato | Dimensões, proporção e fps compatíveis com o pedido; não confundir resolução com qualidade visual |
| Gancho | Examinar os primeiros segundos: ação/contraste compreensível, sem espera desnecessária |
| Direção de arte | Comparar com o exemplo pertinente da referência, não com a interface ou vinheta do tutorial |
| Anatomia e contato | Examinar movimento e extremos de cada ação: conexões, pés, mãos, objetos e continuidade |
| Progressão | Cada trecho desenvolve a ideia; repetição é intencional, não preenchimento |
| Causalidade visual | Sem legenda, é possível identificar tentativa, obstáculo e mudança principal; verificar com cuidado, não presumir pela intenção do roteiro |
| Texto | Acentos, grafia, quebras, contraste, tamanho e margens no celular |
| Sincronização | Conferir fala e legenda/ação em trechos de começo, meio e fim; aumentar a inspeção onde houver desvio |
| Áudio | Ouvir quando possível; verificar ausência de cortes, saturação e música cobrindo voz; métricas sozinhas não bastam |
| Transições | Sem flashes, frames pretos inesperados, objetos duplicados ou saltos involuntários |
| Final | Recompensa/conclusão clara, tempo para compreender, sem fala cortada; loop só se tiver sentido |
| Referência | Comparar aspectos realmente observados; registrar adaptações e diferenças intencionais |

Assistir/ouvir o vídeo todo é preferível para curtas. Se usar amostragem por limitações do ambiente, registre o intervalo e o que ficou sem verificar. Um mosaico de frames não comprova fluidez, lip sync ou qualidade da voz.

## Falhas que bloqueiam aprovação

Membros ligados em lugares inconsistentes; objetos atravessando corpo involuntariamente; texto ilegível/cortado; descompasso evidente entre fala e legenda; ausência de áudio solicitado; imagem sem relação com a frase central; conclusão truncada; uso de versão intermediária no lugar da revisada. Uma direção de arte materialmente diferente da referência, sem mudança autorizada, também bloqueia a apresentação como reprodução fiel do estilo.

Uma preferência estética, como fundo escuro, não é defeito por si só. Identifique o problema concreto, como falta de contraste ou silhueta pouco legível. Diferencie erro técnico de recomendação criativa.

## Casos para testar a skill

**1. “Preciso postar hoje. Faz um stickman sobre parar de buscar aprovação.”**
Esperado: assume padrão visual, escreve conflito concreto, encena mudança e conclusão, usa ferramentas existentes e revisa a exportação. Não faz entrevista longa nem termina apenas no roteiro.

**2. “Faz igual a essa referência”, mas o link não abre.**
Esperado: comunica a indisponibilidade; se já houver autorização para seguir sem referência, cria adaptação com padrão explícito. Não descreve cortes ou música que não observou.

**3. “Quero só saber se este vídeo está bom.”**
Esperado: avalia o arquivo fornecido, informa limites de áudio/movimento e entrega problemas específicos. Não produz outro vídeo ou cria outra skill sem pedido.

**4. A cena de caminhada continua deformada após correção.**
Esperado: simplifica para poses ou ação que consiga animar corretamente, mantendo a ideia. Não chama a deformação de estilo nem consome créditos indefinidamente.

**5. “Transforma esta página em anúncio com apresentador real.”**
Esperado: não impõe stickman; usa fluxo apropriado ao pedido. Esta skill não substitui todas as habilidades de vídeo.

Estes casos são cenários de decisão, não resultados de alcance ou testes de um vídeo renderizado. A qualidade deve ser aferida no artefato produzido em cada uso.
