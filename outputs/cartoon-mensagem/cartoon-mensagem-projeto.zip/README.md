# A mensagem no rascunho — revisão 2 da skill

Curta vertical de cerca de 21 segundos, com cartoon ilustrado original, narração em português brasileiro e sem música.

## O que mudou

O trabalho anterior de linhas e peças foi preservado. Aqui a direção muda: personagem ilustrado com cabelo, expressão e roupa; cenas em apartamento; detalhes de mão/celular; uma mensagem reconhecível é escrita, apagada e enviada. A consequência é visível no telefone e na expressão final.

A montagem é animação 2D por recortes ilustrados em camadas, com braço/celular ligados, inclinação de cabeça e mão de toque separada. Não é vídeo generativo nem animação de corpo inteiro. O método e o acabamento foram testados num trecho curto antes da exportação completa.

## Referência e limites

O YouTube bloqueou o tutorial indicado na skill. A direção de arte segue a descrição e a análise editorial fornecidas pelo usuário na própria skill; não houve comparação visual direta com quadros do tutorial. O contrato visual está em CONTRATO-VISUAL.md.

A exportação é decodificada integralmente, com metadados, áudio, duração e amostragem de quadros verificadas. A revisão visual usa quadros a cada 0,5 s e quadros adicionais no contato e envio. Isso não equivale a assistir integralmente à reprodução. Não houve ferramenta de escuta; naturalidade e pronúncia não foram aprovadas por audição. Os tempos das legendas vêm dos WAVs gerados; o toque é aproximado ao fim da frase, sem alegação de alinhamento fonético.

## Produzir novamente neste ambiente

1. `/workspace/tts-kokoro/.venv/bin/python scripts/narrar.py` — reutiliza os WAVs existentes.
2. `python scripts/animar.py --test` — teste de gesto, contato e envio.
3. `python scripts/animar.py` — animação completa.
4. `python scripts/finalizar.py` — mistura voz/efeitos e exporta MP4 e SRT.
5. `python scripts/verificar.py` — verifica a exportação real.

Pillow, NumPy e FFmpeg disponíveis. O modelo de voz está fora do pacote, em `/workspace/tts-kokoro/models/`. Saída padrão em `/workspace/output/`.

## Recursos e direitos

- Personagem, partes de atuação e ambientes: imagens originais geradas para este projeto. O mesmo mestre orientou os recursos de personagem e mãos.
- Narração local Kokoro ONNX, voz `pm_alex`, português brasileiro. Runtime MIT; modelo Apache-2.0. Executado separadamente do VoiceStudio.
- Sem trilha musical; dois efeitos discretos sintetizados no momento do toque/envio.
- Fonte DejaVu Sans: licença em `assets/DejaVu-LICENSE.txt`. Anton, mantida como recurso de produção: SIL OFL, licença em `assets/Anton-LICENSE.txt`.
- Nada de rosto, fala ou música foi extraído da referência original.

Manifesto e storyboard conservam tempos, decisões e vínculo entre ação, fala e recursos. A skill utilizada está incluída em `skill/` no pacote editável.
