# Direção de arte — revisão 2

O tutorial do YouTube indicado na skill foi solicitado, mas a rede retornou bloqueio 403. Não há comparação direta com quadros desse tutorial nesta produção. A fonte de direção é a descrição editorial da skill enviada pelo usuário.

- Família: cartoon ilustrado com contornos de tinta, cel shading e textura discreta; não esqueleto geométrico nem personagem construído de formas básicas.
- Protagonista: adulto brasileiro, cabelo preto curto e desalinhado, pele morena, olhos e sobrancelhas expressivos; moletom vinho com cordões claros, identidade original.
- Recursos: quadro mestre com expressões e partes ilustradas; recortes animados em camadas, celular e gesto de envio em detalhe. Não é vídeo generativo; não alegar atuação corporal produzida por um motor inexistente.
- Cenário: apartamento cotidiano, ambiente desenhado acolhedor, paleta marfim e grafite com vinho/coral nos detalhes.
- Enquadramentos: retrato expressivo, detalhe grande do celular, gesto do polegar, retrato de alívio. A mudança de plano revela informação, não preenche tempo.
- Ação e causalidade: mensagem no rascunho -> texto escrito/apagado -> decisão -> toque real no botão -> mensagem muda para enviada -> expressão aliviada.
- Movimento: braço/celular ligados, cabeça inclinando, postura respirando; no plano de detalhe, polegar se aproxima, toca o envio e recua. Nada de apresentar pan/zoom como atuação de corpo inteiro.
- Texto: duas linhas curtas por trecho, baseadas na fala real; sem título, legenda e CTA simultâneos. Não há propaganda.
- Som: mesma voz portuguesa brasileira pm_alex já instalada. Sem música; apenas efeitos discretos pertinentes.
