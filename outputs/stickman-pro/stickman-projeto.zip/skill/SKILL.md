---
name: stickman-video-pro
description: Dirige e produz vídeos curtos de bonecos de palito expressivos para Reels, TikTok e Shorts, transformando ideias ou referências em narrativa visual, animação, voz e legendas verificadas. Use para "vídeo de stickman", "bonecos de palito", "faz nesse estilo", ou corrigir uma animação stickman fraca. Não aplica esse estilo a todos os vídeos e não promete viralização.
---

# Stickman Video Pro

## Resultado esperado

Entregue uma pequena história visual original, compreensível e expressiva, com bonecos de palito, narração quando solicitada e acabamento verificado. O espectador deve perceber ação, mudança e conclusão; não apenas frases motivacionais sobre imagens repetidas.

Esta skill orienta direção e qualidade. Não fornece por si só motores de vídeo, vozes, credenciais ou garantias de alcance. Descubra ferramentas reais antes de prometer uma produção. Criar a skill não equivale a produzir um vídeo.

## Padrão do usuário

O usuário quer publicar rapidamente e rejeita animações com personagem genérico no computador, poses incoerentes e frases sem demonstração. Na falta de referência acessível, assuma **stickman 2D minimalista e expressivo**, não personagem humano ilustrado com corpo preenchido.

Padrão ajustável: vertical 9:16, 1080 × 1920, 30 fps, aproximadamente 15–30 segundos, composição limpa, uma cor de destaque e texto em português brasileiro quando destinado ao público da Caminhos Digitais. Use o tema e a duração pedidos acima desses padrões. Não adicione propaganda ou CTA comercial se o objetivo for apenas conteúdo editorial.

Publicação hoje exige reduzir complexidade e quantidade de cenas, não abandonar revisão. Não publique ou envie a terceiros sem pedido explícito.

## 1. Entender e escolher o caminho

- Identifique ideia, público, mensagem central e objetivo: entretenimento, explicação, identificação ou oferta. Use o contexto disponível; não repita perguntas já respondidas.
- Se houver referência, abra-a e examine gancho, ações, estilo dos bonecos, enquadramento, ritmo, transições, texto e som. Registre observações e limites. Reaproveite princípios e ritmo com história e recursos próprios; não copie automaticamente fala, cenas, música ou identidade.
- Se a referência estiver inacessível, informe em uma frase e avance com o padrão acima quando o usuário já autorizou. Não diga que seguiu uma referência que não viu.
- Descubra os recursos disponíveis de voz, imagens, animação e montagem. Escolha pela adequação e controle, não pelo número de ferramentas. Não gere imagens, voz ou vídeo desnecessários só porque existem ferramentas.
- Para movimento gráfico 2D controlável, prefira um motor disponível com vetores e timeline, como HyperFrames/GSAP, Remotion/SVG ou equivalente. Para vídeo generativo, confirme que o estilo e a continuidade são controláveis. Leia a skill específica do motor escolhido antes de usá-lo e respeite seus limites. Não imponha instalação ou arquitetura nova a um projeto que já funciona.
- Use a autorização existente para produzir e revisar; não exija aprovação de cada cena. Só pergunte se a informação ausente muda materialmente o resultado. Operações com cobrança exigem autorização aplicável; não trate prazo curto como autorização ilimitada de créditos.

## 2. Desenvolver a ideia antes de renderizar

Defina uma frase central e uma situação concreta que a demonstre. Estruture livremente **gancho visual → problema/contraste → tentativa ou virada → consequência/recompensa**. O número de cenas deve servir à história, não a uma quota.

O primeiro segundo precisa apresentar algo legível e interessante: conflito, ação incompleta, contraste ou pergunta visual. Não comece com logotipo, tela vazia ou introdução genérica. Uma frase impactante sem ação correspondente não basta.

Crie um storyboard curto por trecho com tempo estimado, fala, ação observável, enquadramento, texto e som. Cada trecho deve responder: **o que muda na imagem e por que isso ajuda a entender a ideia?** Se só muda a legenda, reescreva a cena.

Exemplo de direção, não roteiro obrigatório: para “trocar aprovação por execução”, um boneco tenta segurar vários sinais de aprovação e perde a tarefa; depois escolhe uma tarefa concreta, erra, ajusta e termina. O resultado visível substitui a declaração abstrata de que ele “tem foco”.

Quando houver produção autorizada, mostre apenas um resumo curto e continue. Preserve roteiro já aprovado, salvo ajustes necessários explicitados.

## 3. Construir bonecos e movimento com intenção

- Silhueta simples: cabeça, tronco, braços e pernas finos; anatomia consistente. Rosto opcional e mínimo. Identidade pode vir de uma cor ou acessório estável.
- Mantenha proporções, comprimento de membros e pontos de articulação consistentes. Animar uma pose não deve fazer nascer membros ou trocar conexão de articulações.
- Defina poses-chave claras e trajetória do movimento. Use antecipação, ação e acomodação quando úteis, com pausas que permitam compreender o gesto. Não balance partes do corpo aleatoriamente para simular vida.
- Ao andar, pés precisam ter contato convincente e deslocamento coerente. Ao pegar um objeto, mão e objeto devem se encontrar; o objeto não deve atravessar corpo ou teletransportar sem intenção narrativa.
- Evite movimentos corporais complexos se não houver rig ou ferramenta capaz. Uma ação curta e bem executada vale mais que deformações constantes. Não substitua ação por zoom em figura parada e chame isso de animação expressiva.
- Encene emoções por postura, distância, reação e tempo, não apenas por emojis ou texto. Humor e exagero são opcionais e devem ser compreensíveis.
- Preserve continuidade espacial e visual entre cenas. Cortes e mudanças de escala devem ajudar a ação; não faça cortes rápidos sem motivo nem mantenha uma imagem sem função por tempo excessivo.

## 4. Voz, legendas e som

Leia [references/producao-e-verificacao.md](references/producao-e-verificacao.md) antes de montar voz/legendas e antes da entrega final.

Se houver narração, use voz real disponível e apropriada ao público, com dicção e intenção. Não clone voz de referência sem autorização. Se o usuário já escolheu uma voz, preserve-a. Gere uma amostra curta antes de uma narração longa quando houver risco de pronúncia ou estilo inadequado.

Use a duração e os eventos da fala real para ajustar as cenas. Não sincronize legendas apenas dividindo duração total por número de frases. Preserve fonte de texto e tempos; legenda deve acompanhar o que é dito. Texto de ênfase é um recurso separado, não precisa repetir cada palavra.

Música e efeitos são opcionais. Use apenas material autorizado, com volume que preserve a fala; silêncio intencional pode funcionar. Não adicione trilha genérica para esconder uma direção fraca.

## 5. Verificar o vídeo real e corrigir

Examine a exportação final, não apenas código, storyboard ou prévia do editor. Verifique começo, transições, movimento, final, áudio e legendas. Ouça quando houver reprodução de áudio disponível. Se só puder analisar quadros ou transcrição, declare esse limite e não aprove a qualidade sonora como se tivesse ouvido.

Há duas verificações distintas: **técnica** (arquivo abre, dimensões, áudio, sincronização, texto e movimentos sem defeitos) e **criativa** (gancho, compreensão, progressão, recompensa e pertinência à referência). Passar em uma não prova a outra.

Corrija problemas observados e renderize novamente os trechos afetados. Priorize no máximo duas rodadas completas de revisão por padrão; se permanecer um defeito importante, simplifique a cena em vez de regenerar indefinidamente. Não imponha gastos adicionais sem autorização. Limite de tempo ou recursos não transforma defeito em qualidade aprovada.

Não entregue como “final pronto” quando houver deformação evidente, texto cortado, áudio ausente quando solicitado, palavra errada ou cena sem conclusão. Entregue o estado real e o bloqueio específico se não puder resolver.

## Entrega

Entregue o MP4 quando a produção foi pedida, projeto editável/roteiro/tempos necessários à reutilização e uma nota curta do que foi verificado. Para uma revisão, entregue os problemas observados com tempos aproximados ou exatos conforme a evidência, sem modificar o original por suposição.

Não crie relatórios extensos se o usuário precisa publicar hoje. Explique apenas mudanças relevantes e limitações. Nunca afirme “vai viralizar”, percentuais de sucesso ou retenção medida sem dados. Diga qual decisão criativa foi usada para favorecer compreensão e atenção, como hipótese editorial.
