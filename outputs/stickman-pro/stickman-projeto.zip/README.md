# Stickman Video Pro — O que você constrói fica

21,1 segundos, 1080 × 1920, 30 fps. Uma história visual original: aprovação distrai, a peça cai, o boneco tenta construir uma ponte, erra, ajusta um apoio, termina e transporta a bola pela ponte.

## Aplicação da skill
- Stickman minimalista de linhas, não personagem humano preenchido.
- Uma tarefa observável desenvolve a mensagem, em vez de personagem genérico no computador.
- Pés fixos, membros de comprimento constante, mãos ligadas aos pontos da peça, trajetória de levantamento antes da rotação para evitar atravessar os apoios.
- Voz portuguesa brasileira já existente: Kokoro ONNX, pm_alex. Licença do modelo Apache-2.0; runtime MIT. Não há clonagem de voz.
- Sem trilha genérica. Somente narração e efeitos originais ligados às ações.

## Reproduzir no ambiente
1. /workspace/tts-kokoro/.venv/bin/python scripts/narrar.py
2. python scripts/checar_colisoes.py
3. python scripts/animar.py --test
4. python scripts/animar.py
5. python scripts/finalizar.py
6. python scripts/verificar.py

Pillow, NumPy e FFmpeg já estão instalados. Modelo de voz fora deste pacote: /workspace/tts-kokoro/models/kokoro-v1.0.onnx e voices-v1.0.bin. O script reutiliza os WAVs existentes. Manifesto e roteiro conservam tempos e decisões.

## Verificação e limites
- Decodificação integral do MP4; duração, áudio AAC estéreo 48 kHz, resolução e fps verificados.
- 633 quadros calculados: membros com comprimento constante e pés fixos; 292 verificações de contato; nenhuma interpenetração geométrica entre a peça e os apoios.
- Quadros do MP4 examinados em intervalos de 0,25 s, incluindo os extremos das ações e a leitura em tamanho reduzido. Isso não equivale a assistir a reprodução integral.
- Narração marcada pelos tempos dos arquivos de fala gerados. Verificados volume, cortes técnicos e silêncios; não houve escuta disponível para aprovar naturalidade e pronúncia.
- Fonte Anton sob SIL Open Font License, incluída em assets/Anton-LICENSE.txt.

As versões anteriores foram preservadas. A referência orientou a oposição entre aprovação e trabalho e a ênfase tipográfica; esta é uma adaptação de narrativa e estilo, sem reaproveitar rosto, fala ou música do vídeo enviado.
