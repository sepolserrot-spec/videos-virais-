from pathlib import Path
import os,json
os.environ['OMP_NUM_THREADS']='2'
import numpy as np,soundfile as sf
from kokoro_onnx import Kokoro
P=Path(__file__).resolve().parents[1]
texts=['Quanto mais eu tentava agradar todo mundo, menos eu terminava.','Então eu parei de correr atrás de aplausos.','Escolhi uma coisa.','Tentei. Errei.','Ajustei.','E terminei.','A aprovação muda. O que você constrói, fica.']
mins=[4.4,3.3,2.0,2.5,2.2,2.2,4.4];visual=['distracao','virada','escolha','erro','ajuste','conclusao','recompensa'];k=None;sr=24000;chunks=[np.zeros(int(.10*sr))];cursor=.10;scenes=[]
for i,(text,minimum,typ) in enumerate(zip(texts,mins,visual)):
 f=P/f'assets/voz-{i}.wav'
 if f.exists():a,sr=sf.read(f)
 else:
  if k is None:k=Kokoro('/workspace/tts-kokoro/models/kokoro-v1.0.onnx','/workspace/tts-kokoro/models/voices-v1.0.bin')
  a,sr=k.create(text,voice='pm_alex',lang='pt-br',speed=1.0);sf.write(f,a,sr)
 dur=max(len(a)/sr+.22,minimum);gap=dur-len(a)/sr
 scenes.append({'id':i,'visual':typ,'start':0 if i==0 else cursor,'voice_start':cursor,'voice_end':cursor+len(a)/sr,'duration':dur+(.10 if i==0 else 0),'text':text})
 chunks.extend([a,np.zeros(round(gap*sr))]);cursor+=dur;print(i,round(dur,2),text,flush=True)
a=np.concatenate(chunks);sf.write(P/'assets/narracao.wav',a,sr)
m={'title':'O que você constrói fica','skill':'stickman-video-pro','version':3,'format':{'w':1080,'h':1920,'fps':30},'duration':len(a)/sr,'voice':{'engine':'Kokoro ONNX','preset':'pm_alex','lang':'pt-br','source':'assets/narracao.wav','license':'Apache-2.0'},'story':'Trocar aprovação por uma tarefa concreta: errar, corrigir o apoio e terminar uma ponte que funciona.','scenes':scenes,'status':'voice_ready','animation':'Minimalist stickman with fixed limb lengths, planted feet, IK arms and contact-bound objects; all artwork procedural.'}
(P/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
(P/'roteiro.md').write_text('# O que você constrói fica\n\n'+'\n\n'.join(f'**{s["start"]:.2f}s — {s["visual"]}**\n{s["text"]}' for s in scenes)+'\n\nA história substitui a sequência de frases anteriores para demonstrar a mensagem com uma tarefa e uma consequência visível.\n')
