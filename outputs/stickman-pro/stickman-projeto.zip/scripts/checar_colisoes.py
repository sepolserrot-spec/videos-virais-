import animar as a
import numpy as np,json,math
from pathlib import Path

def clip(poly,axis,value,keep_greater):
 out=[]
 def inside(p):return p[axis]>=value-1e-8 if keep_greater else p[axis]<=value+1e-8
 for p,q in zip(poly,poly[1:]+poly[:1]):
  ip,iq=inside(p),inside(q)
  if ip:out.append(p)
  if ip!=iq:
   f=(value-p[axis])/(q[axis]-p[axis]);out.append(p+(q-p)*f)
 return out

def area(poly):
 if len(poly)<3:return 0
 x=np.array(poly);return abs(float(np.dot(x[:,0],np.roll(x[:,1],1))-np.dot(x[:,1],np.roll(x[:,0],1))))/2
issues=[];max_area=0
for n in range(math.ceil(a.D*a.FPS)):
 s=a.state(n/a.FPS);beam=s['beam'];poly=[a.point(beam,x,y) for x,y in [(-80,-14),(80,-14),(80,14),(-80,14)]]
 for x in [s['support'],790]:
  p=poly[:]
  for axis,value,greater in [(0,x-24,True),(0,x+24,False),(1,960,True),(1,1140,False)]:
   if p:p=clip(p,axis,value,greater)
  value=area(p);max_area=max(max_area,value)
  if value>.1:issues.append({'t':round(n/a.FPS,3),'scene':s['i'],'support':x,'overlap_area':value})
 if max(p[1] for p in poly)>1140+.1:issues.append({'t':n/a.FPS,'floor_penetration':True})
Path('/workspace/stickman-pro/qc/colisoes.json').write_text(json.dumps({'frames':math.ceil(a.D*a.FPS),'max_overlap_area_px2':max_area,'issues':issues},indent=2))
print('Collision checks:',len(issues),'issues; max area',max_area)
if issues:print(issues[:8]);raise SystemExit(1)
