from pathlib import Path
import json,subprocess,math,sys
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parents[1];V=Path('/workspace/output/stickman-pro.mp4');M=json.loads((P/'manifest.json').read_text())
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True)
d=json.loads(run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(V)]).stdout);v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio');dur=float(d['format']['duration'])
assert abs(dur-M['duration'])<.05;assert(v['width'],v['height'],v['pix_fmt'])==(1080,1920,'yuv420p');assert a['sample_rate']=='48000' and a['channels']==2
r=run(['ffmpeg','-hide_banner','-i',str(V),'-vf','blackdetect=d=0.3:pix_th=0.05','-af','silencedetect=n=-50dB:d=3,loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);(P/'qc/ffmpeg.log').write_text(r.stderr);assert 'black_start:' not in r.stderr;assert 'silence_start:' not in r.stderr
sys.path.insert(0,'/workspace/videos-virais-/.agents/skills/video-viral');import desmontar as kit
# Sample every 0.25 s across the exported file, plus action extrema, at phone width.
times=[round(i*.25,2) for i in range(math.ceil(dur/.25)) if i*.25<dur]
thumbs=[kit.quadro(V,t,135) for t in times]
for page in range(math.ceil(len(times)/24)):
 small=thumbs[page*24:(page+1)*24];ts=times[page*24:(page+1)*24];kit.folha(small,[f'{t:.2f}s' for t in ts],6,P/f'qc/exportacao-{page+1}.jpg')
hero=[s['start']+s['duration']*.72 for s in M['scenes']];kit.folha([kit.quadro(V,t,270) for t in hero],[f'{t:.1f}s' for t in hero],4,P/'qc/historia.jpg')
rig=json.loads((P/'qc/rig.json').read_text());col=json.loads((P/'qc/colisoes.json').read_text())
report={'duration_s':dur,'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'audio_codec':a['codec_name'],'integrated_lufs':kit.volume(V),'decode_ok':True,'black_frames':False,'silences_over_3s':False,'rig':rig,'prop_collision_issues':len(col['issues']),'exported_frame_sampling_s':.25,'audio_review':'Technical decoding, sentence generation timestamps and loudness measurements. No auditory review available; naturalness and pronunciation not approved by listening.','motion_review':'Exported frame sequences sampled at 0.25s, action extrema examined, rig length and prop collision constraints checked on every authored frame. Frame sheets do not prove full playback fluency.','story':'Approval distraction -> failed bridge -> support adjustment -> completed bridge transports ball.','bytes':int(d['format']['size'])}
(P/'qc/report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));M['status']='validated_technical';(P/'manifest.json').write_text(json.dumps(M,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False))
