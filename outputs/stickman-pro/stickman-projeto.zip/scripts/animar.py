"""A small physical story. Planted feet, two-bone IK, contact-bound props, no photos."""
from pathlib import Path
import math,json,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];M=json.loads((P/'manifest.json').read_text());SC=M['scenes'];D=M['duration'];W,H,FPS=1080,1920,30
BG='#f5f1e9';INK='#192a31';RED='#e64c42';MUTED='#c9c8bf';FONTS={}
def ease(v):v=max(0,min(1,v));return v*v*(3-2*v)
def mix(a,b,u):return np.array(a,dtype=float)*(1-u)+np.array(b,dtype=float)*u
def ik(a,b,L,side):
 a=np.array(a);b=np.array(b);v=b-a;dist=float(np.linalg.norm(v));
 if dist>2*L+.01:raise ValueError(f'Unreachable hand/foot: {a}, {b}, distance={dist}, limit={2*L}')
 mid=(a+b)/2;perp=np.array([-v[1],v[0]])/max(dist,.001);return mid+side*math.sqrt(max(0,L*L-dist*dist/4))*perp

def point(beam,dx=0,dy=0):
 x,y,angle=beam;a=math.radians(angle);return np.array([x+dx*math.cos(a)-dy*math.sin(a),y+dx*math.sin(a)+dy*math.cos(a)])
FLOOR=(610.,1060.,90.);POSE=(380.,940.,10.);PICK=(400.,1008.,40.);PLACE=(410.,940.,24.)
def carry_path(u,initial,endx):
 if u<.56:return mix(initial,[initial[0],860,90],ease((u-.32)/.24))
 if u<.78:return mix([initial[0],860,90],[endx,860,0],ease((u-.56)/.22))
 return mix([endx,860,0],[endx,946,0],ease((u-.78)/.22))
def state(t):
 i=max(j for j,s in enumerate(SC) if t>=s['start']);s=SC[i];u=min(1,max(0,(t-s['start'])/s['duration']));local=t-s['start']
 pose=np.array(POSE);beam=np.array(FLOOR);support=560.;look='down';mood='neutral';contact=[];heart=1.;sweep=0.;ball=np.array([790.,900.]);rope=1.;reward=0.
 neutralL=np.array([300.,965.]);neutralR=np.array([580.,700.]);left=neutralL;right=neutralR
 if i==0:
  pose=np.array(POSE);drop=ease((local-1.65)/.45);held=np.array([650.,840.,0.]);turn=ease((local-1.35)/.30);beam=mix([650,840,90],FLOOR,drop) if local>=1.65 else mix(held,[650,840,90],turn)
  if local<1.35:right=point(beam,-15,0);contact=['R']
  else:right=mix(point(held,-15,0),[625,570],ease((local-1.35)/.35))
  left=np.array([225+8*math.sin(local*3),610-12*math.sin(local*2)])
  look='up' if local<2.2 else 'down';mood='worried'
 elif i==1:
  sweep=ease((u-.14)/.55);heart=1-sweep;right=mix([625,570],[650,650],ease(u/.6));left=neutralL;look='right';mood='decisive'
 elif i==2:
  heart=0.;look='down';crouch=ease(u/.32)
  if u<.32:
   pose=mix(POSE,PICK,crouch);left=mix(neutralL,point(beam,-55),crouch);right=mix([650,650],point(beam,-15),crouch)
  else:
   lift=ease((u-.32)/.24);pose=mix(PICK,PLACE,lift);beam=carry_path(u,FLOOR,675);left=point(beam,-55);right=point(beam,-15);contact=['L','R']
 elif i==3:
  heart=0.;pose=np.array(PLACE);look='down';mood='worried';fall=ease((u-.23)/.40);beam=mix([675,946,0],[675,1060,90],fall)
  if u<.23:left=point(beam,-55);right=point(beam,-15);contact=['L','R']
  else:left=mix(point([675,946,0],-55),[360,975],ease((u-.23)/.25));right=mix(point([675,946,0],-15),[565,840],ease((u-.23)/.25))
 elif i==4:
  heart=0.;pose=np.array(PLACE);beam=np.array([675.,1060.,90.]);move=ease((u-.28)/.5);support=560+70*move;target=np.array([support-26,1000])
  right=mix([565,840],target,ease(u/.28));left=np.array([360.,975.]);look='right';mood='decisive'
  if u>=.28:contact=['SUPPORT']
 elif i==5:
  heart=0.;support=630.;beam=np.array([675.,1060.,90.]);pickup=np.array([410,1008,40]);crouch=ease(u/.32)
  if u<.32:
   pose=mix(PLACE,pickup,crouch);left=mix([360,975],point(beam,-55),crouch);right=mix([604,1000],point(beam,-15),crouch)
  else:
   lift=ease((u-.32)/.24);pose=mix(pickup,PLACE,lift);beam=carry_path(u,[675,1060,90],710);left=point(beam,-55);right=point(beam,-15);contact=['L','R']
  look='right';mood='hopeful'
 else:
  heart=0.;support=630.;beam=np.array([710.,946.,0.]);pose=mix(PLACE,POSE,ease((u-.15)/.28));hip=np.array(pose[:2]);lean=math.radians(pose[2]);sh=hip+np.array([math.sin(lean)*200,-math.cos(lean)*200]);raise_arm=ease((u-.15)/.28)
  left=mix(point(beam,-55),sh+np.array([-155,-195]),raise_arm);right=mix(point(beam,-15),sh+np.array([155,-195]),raise_arm)
  fall=ease(u/.13);roll=ease((u-.13)/.55);ball=np.array([790-160*roll,900+17*fall]);rope=1-fall;reward=ease((u-.68)/.18);mood='happy';look='right'
 # Rig geometry derives every limb from its real parent point.
 hip=np.array(pose[:2]);a=math.radians(pose[2]);up=np.array([math.sin(a),-math.cos(a)]);shoulder=hip+up*200;head=shoulder+up*83
 joints={'hip':hip,'shoulder':shoulder,'head':head,'left':left,'right':right,'footL':np.array([325.,1140.]),'footR':np.array([435.,1140.])}
 joints['elbowL']=ik(shoulder+[-6,0],left,150,-1 if left[1]<shoulder[1]-50 and left[0]<shoulder[0] else 1);joints['elbowR']=ik(shoulder+[6,0],right,150,1 if right[1]<shoulder[1]-50 and right[0]>shoulder[0] else -1)
 joints['kneeL']=ik(hip,joints['footL'],115,1);joints['kneeR']=ik(hip,joints['footR'],115,-1)
 return dict(i=i,u=u,local=local,beam=beam,support=support,j=joints,heart=heart,sweep=sweep,look=look,mood=mood,contact=contact,ball=ball,rope=rope,reward=reward)

def bone(d,a,b,w=13,col=INK):
 a=tuple(a);b=tuple(b);d.line((a,b),fill=col,width=w);r=w/2
 for x,y in [a,b]:d.ellipse((x-r,y-r,x+r,y+r),fill=col)
def beamdraw(d,b):
 corners=[tuple(point(b,x,y)) for x,y in [(-80,-14),(80,-14),(80,14),(-80,14)]];d.polygon(corners,fill=BG);d.line(corners+[corners[0]],fill=INK,width=8,joint='curve');a=point(b,-13,-10);bb=point(b,13,10);d.line((tuple(a),tuple(bb)),fill=RED,width=6)
def heartdraw(im,cx,cy,alpha):
 if alpha<=0:return
 lay=Image.new('RGBA',(W,H));d=ImageDraw.Draw(lay);col=(230,76,66,int(255*alpha));d.ellipse((cx-24,cy-19,cx+2,cy+8),fill=col);d.ellipse((cx-2,cy-19,cx+24,cy+8),fill=col);d.polygon([(cx-24,cy-5),(cx+24,cy-5),(cx,cy+27)],fill=col);return Image.alpha_composite(im.convert('RGBA'),lay).convert('RGB')

def illustration(t):
 st=state(t);j=st['j'];im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 # One continuous stage; the task remains in the same place across the story.
 d.line((110,1148,960,1148),fill=MUTED,width=3)
 for x in [st['support'],790]:
  d.rounded_rectangle((x-24,960,x+24,1140),radius=6,fill='#ebe7de',outline=INK,width=7)
  d.line((x-10,990,x-10,1115),fill='#d5d4cb',width=3)
 # Waiting ball, released only when the bridge can carry it.
 bx,by=st['ball'];rope=st['rope']
 if rope>0:
  yend=650+(by-15-650)*rope;d.line((790,650,790,yend),fill='#b6b8b0',width=3);d.ellipse((784,642,796,654),fill=INK)
 # Character's planted feet have fixed world positions; knees accommodate leaning/crouching.
 for side in ['L','R']:
  bone(d,j['hip'],j['knee'+side]);bone(d,j['knee'+side],j['foot'+side]);x,y=j['foot'+side];bone(d,(x-14,y),(x+23,y),12)
 bone(d,j['hip'],j['shoulder'],15);neck=j['shoulder']+(j['head']-j['shoulder'])*.43;bone(d,j['shoulder'],neck,12)
 for side,hand in [('L','left'),('R','right')]:
  sh=j['shoulder']+([-6,0] if side=='L' else [6,0]);bone(d,sh,j['elbow'+side]);bone(d,j['elbow'+side],j[hand]);x,y=j[hand];d.ellipse((x-8,y-8,x+8,y+8),fill=INK)
 hx,hy=j['head'];d.ellipse((hx-48,hy-48,hx+48,hy+48),fill=BG,outline=INK,width=11)
 # A stable red headband is the only character identifier.
 d.arc((hx-43,hy-43,hx+43,hy+43),195,345,fill=RED,width=8)
 dy=-7 if st['look']=='up' else 7 if st['look']=='down' else 0;dx=8 if st['look']=='right' else 0
 blink=t%4.4>4.28
 for ex in [hx-14+dx,hx+13+dx]:
  if blink:d.line((ex-4,hy-6+dy,ex+4,hy-6+dy),fill=INK,width=3)
  else:d.ellipse((ex-3,hy-10+dy,ex+3,hy-3+dy),fill=INK)
 if st['mood']=='happy':d.arc((hx-18,hy+2,hx+21,hy+25),0,180,fill=INK,width=4)
 elif st['mood']=='worried':d.arc((hx-15,hy+12,hx+15,hy+30),185,355,fill=INK,width=3)
 else:d.line((hx-9,hy+19,hx+12,hy+19),fill=INK,width=3)
 beamdraw(d,st['beam'])
 # Hands stay on exact local prop coordinates when gripping, not near an unrelated object.
 if 'L' in st['contact'] or 'R' in st['contact']:
  for side,hand in [('L','left'),('R','right')]:
   if side in st['contact']:
    x,y=j[hand];d.ellipse((x-8,y-8,x+8,y+8),fill=INK)
 d.ellipse((bx-15,by-15,bx+15,by+15),fill=RED)
 theta=(790-bx)/15;bone(d,(bx+9*math.cos(theta),by+9*math.sin(theta)),(bx-9*math.cos(theta),by-9*math.sin(theta)),3,BG)
 if st['reward']>0:
  r=22+35*st['reward'];d.arc((630-r,917-r,630+r,917+r),30,330,fill=RED,width=3)
  for ang in [-45,20,95]:
   ar=math.radians(ang);x=630+55*math.cos(ar);y=917-55*math.sin(ar);bone(d,(x,y),(x+12*math.cos(ar),y-12*math.sin(ar)),3,RED)
 # A wobbling demand for approval becomes physically absent after the sweep.
 if st['heart']>0:
  for k,(x,y) in enumerate([(220,570),(420,440),(625,570)]):
   x+=st['sweep']*(1100-x);y-=st['sweep']*120
   if st['i']==0:y+=7*math.sin(t*3+k)
   im=heartdraw(im,x,y,st['heart'])
 return im,st

CAPTIONS=[['QUANTO MAIS EU TENTAVA','AGRADAR TODO MUNDO,','MENOS EU TERMINAVA.'],['ENTÃO EU PAREI DE CORRER','ATRÁS DE APLAUSOS.'],['ESCOLHI UMA COISA.'],['TENTEI.','ERREI.'],['AJUSTEI.'],['E TERMINEI.'],['A APROVAÇÃO MUDA.','O QUE VOCÊ CONSTRÓI,','FICA.']]
CACHE={}
def frame(t):
 im,st=illustration(t);i=st['i'];lines=CAPTIONS[i];top=1380 if len(lines)==3 else 1420
 if len(lines)==1:top=1460
 for n,text in enumerate(lines):
  offset=0 if i!=3 else (0 if n==0 else .55);e=ease((st['local']-offset)/.13)
  if e<=0:continue
  fs=78 if len(lines)>1 else 108
  while True:
   if fs not in FONTS:FONTS[fs]=ImageFont.truetype(str(P/'assets/Anton.ttf'),fs)
   if FONTS[fs].getlength(text)<900:break
   fs-=2
  key=(text,fs,n==len(lines)-1)
  if key not in CACHE:
   lay=Image.new('RGBA',(1020,155));d=ImageDraw.Draw(lay);d.text((510,75),text,font=FONTS[fs],anchor='mm',fill=RED if key[2] else INK);CACHE[key]=lay
  layer=CACHE[key].copy();layer.putalpha(layer.getchannel('A').point(lambda x:int(x*e)));im.paste(layer,(30,int(top+n*104-75+(1-e)*14)),layer)
 return im

def verify_rig():
 max_error=0.;count=0
 for n in range(math.ceil(D*FPS)):
  st=state(n/FPS);j=st['j']
  for a,b,L in [('hip','kneeL',115),('kneeL','footL',115),('hip','kneeR',115),('kneeR','footR',115),('hip','shoulder',200),('elbowL','left',150),('elbowR','right',150)]:max_error=max(max_error,abs(np.linalg.norm(j[a]-j[b])-L))
  for side,dx in [('L',-55),('R',-15)]:
   if side in st['contact']:
    expected=point(st['beam'],dx);actual=j['left' if side=='L' else 'right'];assert np.linalg.norm(expected-actual)<.00001;count+=1
  if 'SUPPORT' in st['contact']:assert np.linalg.norm(j['right']-np.array([st['support']-26,1000]))<.00001;count+=1
 assert max_error<.0001,max_error
 (P/'qc/rig.json').write_text(json.dumps({'frames_checked':math.ceil(D*FPS),'max_length_error_px':float(max_error),'contact_checks':count,'foot_positions_fixed':True},indent=2))
 print('Rig verified',max_error,count,flush=True)

if __name__=='__main__':
 verify_rig()
 if '--frames' in sys.argv:
  for i,s in enumerate(SC):
   for label,q in [('inicio',.05),('meio',.5),('fim',.94)]:frame(s['start']+s['duration']*q).save(P/f'qc/cena-{i}-{label}.png')
  raise SystemExit()
 start=SC[5]['start'] if '--test' in sys.argv else 0;duration=3 if '--test' in sys.argv else D;out=P/('build/teste-contato.mp4' if '--test' in sys.argv else 'build/animacao-muda.mp4')
 p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
 for n in range(math.ceil(duration*FPS)):
  p.stdin.write(frame(min(start+n/FPS,D-.001)).tobytes())
  if n%90==0:print(f'{n/FPS:.1f}/{duration:.1f}s',flush=True)
 p.stdin.close();assert p.wait()==0;print('READY',out)
