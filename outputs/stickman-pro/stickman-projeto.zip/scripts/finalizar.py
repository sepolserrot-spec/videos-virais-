from pathlib import Path
import json,subprocess,math,wave
import numpy as np
P=Path(__file__).resolve().parents[1];O=Path('/workspace/output');M=json.loads((P/'manifest.json').read_text());D=M['duration'];sr=48000;n=round(D*sr);audio=np.zeros((n,2));rng=np.random.default_rng(74261)
def thud(at,gain=.14):
 start=round(at*sr);u=np.arange(min(round(.2*sr),n-start))/sr;s=np.sin(2*np.pi*(76*u+.9*(1-np.exp(-u*55))))*np.exp(-u*26)*gain;audio[start:start+len(s)]+=s[:,None]
def air(at):
 start=round(at*sr);u=np.arange(min(round(.3*sr),n-start))/sr;noise=np.convolve(rng.normal(size=len(u)),np.ones(15)/15,'same');s=noise*np.sin(np.pi*u/.3)**2*.035;audio[start:start+len(s),0]+=s;audio[start:start+len(s),1]+=s*.8
thud(2.1,.10);thud(M['scenes'][3]['start']+M['scenes'][3]['duration']*.63,.12);thud(M['scenes'][5]['start']+M['scenes'][5]['duration']*.98,.07);air(M['scenes'][1]['start']+.7)
start=round((M['scenes'][6]['start']+M['scenes'][6]['duration']*.7)*sr);u=np.arange(min(round(.65*sr),n-start))/sr;chime=(np.sin(2*np.pi*880*u)+.3*np.sin(2*np.pi*1320*u))*np.exp(-u*8)*(1-np.exp(-u*150))*.045;audio[start:start+len(u)]+=chime[:,None]
with wave.open(str(P/'assets/efeitos.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((np.clip(audio,-1,1)*32700).astype('<i2').tobytes())
cmd=['ffmpeg','-y','-v','error','-i','build/animacao-muda.mp4','-i','assets/narracao.wav','-i','assets/efeitos.wav','-filter_complex','[1:a]aformat=channel_layouts=stereo,loudnorm=I=-16:TP=-1.5:LRA=8[v];[v][2:a]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-16:TP=-1.5:LRA=9[a]','-map','0:v','-map','[a]','-t',str(D),'-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-movflags','+faststart',str(O/'stickman-pro.mp4')]
subprocess.run(cmd,check=True,cwd=P)
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(O/'stickman-legendas.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(s["voice_start"])} --> {stamp(s["voice_end"])}\n{s["text"]}' for i,s in enumerate(M['scenes']))+'\n')
M['status']='rendered';(P/'manifest.json').write_text(json.dumps(M,indent=2,ensure_ascii=False));print('READY',O/'stickman-pro.mp4')
