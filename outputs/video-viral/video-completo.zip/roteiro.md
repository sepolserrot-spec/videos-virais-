# O trabalho fala por você

Formato: 9:16, 1080 × 1920, 30 fps.

**0.0–3.5s** — Você não precisa impressionar todo mundo.
Visual: assets/img/shoes.png

**3.5–7.0s** — Precisa ter orgulho do que entrega.
Visual: assets/img/desk.png

**7.0–10.5s** — Reconhecimento sem trabalho é só barulho.
Visual: assets/img/craft.png

**10.5–13.3s** — Escolha uma direção.
Visual: assets/img/runner.png

**13.3–16.3s** — Faça o que precisa ser feito.
Visual: assets/img/craft.png

**16.3–18.3s** — E repita.
Visual: assets/img/shoes.png

**18.3–22.0s** — Até o seu trabalho falar por você.
Visual: assets/img/runner.png

Inspiração: contraste, gancho, imagens de apoio e palavra final forte da referência. Texto, imagens e trilha novos.
