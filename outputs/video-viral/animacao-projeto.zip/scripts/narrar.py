from pathlib import Path
import os,json
os.environ['OMP_NUM_THREADS']='2';os.environ['ORT_LOG_SEVERITY_LEVEL']='3'
import numpy as np,soundfile as sf
from kokoro_onnx import Kokoro
P=Path(__file__).resolve().parents[1];k=Kokoro('/workspace/tts-kokoro/models/kokoro-v1.0.onnx','/workspace/tts-kokoro/models/voices-v1.0.bin')
print('Portuguese voices:',[v for v in k.get_voices() if v.startswith(('pm_','pf_'))],flush=True)
voice='pm_alex'
texts=['Eu não preciso impressionar todo mundo.','Preciso me orgulhar do que eu entrego.','Enquanto buscam aplausos, eu escolho uma direção.','Faço o que precisa ser feito.','Ajusto o que não funciona.','E repito.','Até o meu trabalho falar por mim.']
visual=['distracoes','trabalho','corrida','trabalho','ajuste','repeticao','final']
chunks=[];cursor=.12;scenes=[]
for i,(text,shot) in enumerate(zip(texts,visual)):
 f=P/f'assets/voz-{i}.wav'
 if f.exists():a,sr=sf.read(f)
 else:
  a,sr=k.create(text,voice=voice,speed=1.05,lang='pt-br');sf.write(f,a,sr)
 gap=.28 if i!=5 else .34
 if i==len(texts)-1:gap=.95
 dur=len(a)/sr+gap
 scenes.append({'id':i,'start':round(cursor-.12 if i==0 else cursor,4),'voice_start':round(cursor,4),'voice_end':round(cursor+len(a)/sr,4),'duration':round(dur+(.12 if i==0 else 0),4),'text':text,'visual':shot})
 chunks.append(a);chunks.append(np.zeros(round(gap*sr)));cursor+=dur
 print(i,round(dur,2),text,flush=True)
a=np.concatenate([np.zeros(round(.12*sr)),*chunks]);sf.write(P/'assets/narracao.wav',a,sr)
(P/'manifest.json').write_text(json.dumps({'title':'O trabalho fala por mim','version':2,'format':{'w':1080,'h':1920,'fps':30},'voice':{'engine':'Kokoro ONNX 0.6.1','model':'Kokoro-82M v1.0','voice':voice,'language':'pt-br','license':'Apache-2.0','file':'assets/narracao.wav'},'duration':len(a)/sr,'scenes':scenes,'status':'voice_ready','skills':['video-viral','gerador-de-video-de-elite'],'animation':'Original articulated 2D animation; no photographic slideshow'},ensure_ascii=False,indent=2))
