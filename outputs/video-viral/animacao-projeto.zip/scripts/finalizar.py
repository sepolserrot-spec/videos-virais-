from pathlib import Path
import json,subprocess,math,shutil
P=Path(__file__).resolve().parents[1];O=Path('/workspace/output');M=json.loads((P/'manifest.json').read_text());D=M['duration']
def run(args):return subprocess.run(args,cwd=P,check=True,capture_output=True,text=True)
run(['ffmpeg','-y','-v','error','-i','assets/narracao.wav','-af','loudnorm=I=-16:TP=-1.5:LRA=8','-ar','48000','assets/voz-master.wav'])
# Voice is dominant; the original instrumental ducks whenever speech is present.
fc='[1:a]aformat=channel_layouts=stereo,asplit=2[v][side];[2:a]aformat=channel_layouts=stereo,volume=0.24[m];[m][side]sidechaincompress=threshold=0.025:ratio=5:attack=12:release=180[duck];[v][duck]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-14:TP=-1.5:LRA=9[out]'
final=O/'animacao-com-voz.mp4'
run(['ffmpeg','-y','-v','error','-i','build/animacao-muda.mp4','-i','assets/voz-master.wav','-i','assets/musica.wav','-filter_complex',fc,'-map','0:v','-map','[out]','-t',str(D),'-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-movflags','+faststart',str(final)])
# Caption clocks follow the actual synthesized sentence boundaries.
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
srt='\n\n'.join(f'{i+1}\n{stamp(s["voice_start"])} --> {stamp(s["voice_end"])}\n{s["text"]}' for i,s in enumerate(M['scenes']))+'\n'
(O/'animacao-legendas.srt').write_text(srt);M['status']='rendered';M['output']=str(final);(P/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2));shutil.copy2(P/'manifest.json',O/'animacao-manifest.json')
(O/'animacao-roteiro.md').write_text('# O trabalho fala por mim\n\n'+'\n\n'.join(f'**{s["voice_start"]:.2f}s** — {s["text"]}' for s in M['scenes'])+'\n\nAnimação 2D original de personagens e objetos, desenhada em código. Voz sintetizada localmente: Kokoro, pm_alex, português brasileiro. O movimento da boca acompanha a energia da fala; não é sincronização fonética precisa.\n')
print('READY',final)
