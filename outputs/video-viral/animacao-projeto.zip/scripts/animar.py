"""Articulated 2D short. All characters, props, motion and backgrounds are drawn in code."""
from pathlib import Path
import math,json,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
P=Path(__file__).resolve().parents[1];M=json.loads((P/'manifest.json').read_text());W,H=1080,1920;FPS=30;D=M['duration'];SC=M['scenes'];RED='#ef4c48';WHITE='#edf2f3';INK='#0d131d';SKIN='#c68c70';DARKSKIN='#8c594a';TEAL='#8bb5bf'
FONTS={};rng=np.random.default_rng(671126)
def font(n):
 if n not in FONTS:FONTS[n]=ImageFont.truetype(str(P/'assets/Anton.ttf'),n)
 return FONTS[n]
def ease(x):x=max(0,min(1,x));return 1-(1-x)**3
def ell(d,box,fill):d.ellipse(box,fill=fill)
def bone(d,a,b,width,color):
 d.line([a,b],fill=color,width=width);r=width/2
 for x,y in [a,b]:ell(d,(x-r,y-r,x+r,y+r),color)
def blendcolor(a,b,t):return tuple(int(x+(y-x)*t) for x,y in zip(a,b))
yy,xx=np.mgrid[0:H,0:W];glow=np.exp(-((xx-770)**2/(550**2)+(yy-370)**2/(800**2)))
arr=np.stack([12+glow*20,17+glow*20,25+glow*23],axis=-1)+rng.normal(0,.65,(H,W,1));BASE=Image.fromarray(np.clip(arr,0,255).astype('uint8'))
# Quiet falloff keeps mobile captions legible without a visible box.
alpha=np.clip((yy-1080)/420,0,1)*215;VEIL=Image.new('RGBA',(W,H),(7,11,17,0));VEIL.putalpha(Image.fromarray(alpha.astype('uint8')))
import wave
with wave.open(str(P/'assets/narracao.wav')) as f:
 SR=f.getframerate();audio=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(float)/32768

def energy(t):
 k=int(t*SR);a=audio[max(0,k-220):min(len(audio),k+220)];return min(1,float(np.sqrt(np.mean(a*a)))*10) if len(a) else 0

def head(im,x,y,r,t,e,profile=False):
 d=ImageDraw.Draw(im);bob=math.sin(t*2.5)*2;y+=bob
 # Neck, ear, jaw and cheek have independent light planes.
 d.rounded_rectangle((x-r*.36,y+r*.64,x+r*.38,y+r*1.34),radius=20,fill=DARKSKIN)
 ell(d,(x-r*.81,y-r*.9,x+r*.84,y+r),SKIN)
 d.polygon([(x+r*.45,y-r*.55),(x+r*.86,y-r*.14),(x+r*1.01,y+r*.24),(x+r*.73,y+r*.36),(x+r*.6,y+r*.81),(x+r*.13,y+r*.98),(x+r*.32,y+r*.2)],fill='#b57b62')
 ell(d,(x-r*.98,y-r*.03,x-r*.55,y+r*.43),'#b37961');d.arc((x-r*.91,y+r*.06,x-r*.66,y+r*.33),270,100,fill=DARKSKIN,width=max(2,int(r*.035)))
 # Sculpted black hair, distinct silhouette rather than a stock icon.
 d.pieslice((x-r*.91,y-r*1.14,x+r*.87,y+r*.42),180,352,fill='#101723')
 d.polygon([(x-r*.85,y-r*.38),(x-r*.74,y-r*.99),(x-r*.18,y-r*1.22),(x+r*.55,y-r*1.02),(x+r*.84,y-r*.55),(x+r*.48,y-r*.45),(x+r*.21,y-r*.62),(x-r*.35,y-r*.53),(x-r*.63,y+r*.1)],fill='#111824')
 d.line([(x-r*.55,y-r*.94),(x-r*.15,y-r*1.04),(x+r*.25,y-r*.93)],fill='#2a3441',width=max(2,int(r*.04)))
 # Brows and a blink cycle; speaking energy drives the mouth.
 blink=(t%3.9)>3.76;ey=y-r*.1
 for ex in [x-r*.14,x+r*.43]:
  d.line([(ex-r*.12,ey-r*.15-e*3),(ex+r*.12,ey-r*.17)],fill='#302631',width=max(3,int(r*.055)))
  if blink:d.line([(ex-r*.10,ey),(ex+r*.10,ey)],fill='#352b2c',width=3)
  else:
   ell(d,(ex-r*.12,ey-r*.055,ex+r*.12,ey+r*.07),'#e6c2a0');ell(d,(ex-r*.025,ey-r*.055,ex+r*.045,ey+r*.07),'#1a232b')
 d.line([(x+r*.2,y+r*.03),(x+r*.14,y+r*.32),(x+r*.32,y+r*.33)],fill='#945e4f',width=max(2,int(r*.025)))
 mx=x+r*.23;my=y+r*.58;mh=max(3,r*(.022+e*.17));mw=r*(.16+e*.04)
 ell(d,(mx-mw,my-mh,mx+mw,my+mh),'#402532')
 if e>.3:d.rectangle((mx-mw*.65,my-mh*.7,mx+mw*.65,my-mh*.3),fill='#eed7bd')
 d.arc((mx-r*.27,my-r*.12,mx+r*.27,my+r*.2),10,170,fill='#a66d58',width=2)

def podcast(t,local):
 im=BASE.copy();d=ImageDraw.Draw(im)
 # Acoustic wall, soft practical red light and table.
 for i in range(9):
  x=-75+i*150;d.polygon([(x,0),(x+100,0),(x+300,1190),(x+200,1190)],fill=('#19212c' if i%2 else '#151c27'))
 d.rounded_rectangle((825,195,845,890),radius=9,fill='#843434');d.rounded_rectangle((830,200,838,885),radius=4,fill=RED)
 d.ellipse((95,135,400,440),outline='#273340',width=3)
 d.rectangle((0,1115,1080,1210),fill='#2a2529');d.polygon([(0,1115),(1080,1115),(1080,1131),(0,1140)],fill='#4a3940')
 # Animated body and arms.
 breathe=3*math.sin(t*3);sy=730+breathe
 d.rounded_rectangle((242,sy,697,1165),radius=110,fill='#1c2636');d.polygon([(415,sy),(550,sy),(610,1165),(330,1165)],fill='#202d40')
 d.line([(445,sy+15),(462,sy+130)],fill='#2d3c51',width=4)
 # Left hand rests and drums lightly; right hand gestures with speech.
 e=energy(t);shoulder=(285,790+breathe);elbow=(225,995);wrist=(425+math.sin(t*5)*7,1075-e*14)
 bone(d,shoulder,elbow,83,'#1b2636');bone(d,elbow,wrist,57,SKIN);ell(d,(wrist[0]-40,wrist[1]-20,wrist[0]+48,wrist[1]+27),SKIN)
 for j in range(4):bone(d,(wrist[0]+j*12,wrist[1]),(wrist[0]+j*12+10,wrist[1]+22-7*math.sin(t*9+j)),10,'#bd8268')
 shoulder=(657,790+breathe);elbow=(755,930-15*math.sin(t*2));wrist=(784+22*math.sin(t*2.3),730-38*e)
 bone(d,shoulder,elbow,80,'#1a2535');bone(d,elbow,wrist,57,SKIN);ell(d,(wrist[0]-31,wrist[1]-40,wrist[0]+32,wrist[1]+22),SKIN)
 for j in range(3):bone(d,(wrist[0]-15+j*13,wrist[1]-12),(wrist[0]-20+j*16,wrist[1]-65-4*math.sin(t*3+j)),11,SKIN)
 head(im,468,528,137,t,e)
 d=ImageDraw.Draw(im)
 # Microphone boom and its mechanical joints move slightly with the desk.
 bone(d,(1090,1140),(842,902),14,'#0a1018');bone(d,(842,902),(613,767),12,'#33404e');bone(d,(842,882),(630,749),6,'#111822');ell(d,(826,880,858,912),'#66717b')
 d.rounded_rectangle((565,690,643,852),radius=36,fill='#080e15');d.rounded_rectangle((574,699,631,811),radius=25,fill='#283545')
 for y in range(714,802,11):d.line((581,y,625,y-3),fill='#0b131d',width=4)
 ell(d,(605,827,613,835),RED)
 # Applause cards are dismissed rather than serving as static decoration.
 for j in range(3):
  phase=local-j*.2;fade=max(0,min(1,phase*3));escape=ease((local-1.3)/.55);cx=170+j*310+(j-1)*escape*400;cy=240+math.sin(t*2+j)*12-escape*330
  layer=Image.new('RGBA',(W,H));z=ImageDraw.Draw(layer);z.rounded_rectangle((cx-58,cy-45,cx+58,cy+45),radius=16,fill=(60,36,46,int(220*fade*(1-escape))),outline=(180,81,82,int(130*fade*(1-escape))),width=2)
  if escape<1:
   col=(239,76,72,int(255*fade*(1-escape)));z.ellipse((cx-22,cy-16,cx+2,cy+7),fill=col);z.ellipse((cx-2,cy-16,cx+22,cy+7),fill=col);z.polygon([(cx-22,cy-3),(cx+22,cy-3),(cx,cy+24)],fill=col)
  im=Image.alpha_composite(im.convert('RGBA'),layer).convert('RGB')
 return im

def work(t,local,adjust=False):
 im=BASE.copy();d=ImageDraw.Draw(im)
 # Window and rain are moving; a physical clock hand advances.
 d.rounded_rectangle((80,140,1000,800),radius=18,fill='#192635',outline='#34404b',width=6)
 for i in range(16):
  x=120+i*58;h=130+(i*97)%220;d.rectangle((x,600-h,x+44,800),fill='#101b29')
  for wy in range(650-h,750,65):d.rectangle((x+10,wy,x+20,wy+15),fill=('#4c4940' if i%3 else '#657d84'))
 for i in range(45):
  x=95+(i*113)%890;y=155+((t*240+i*91)%610);d.line((x,y,x-8,y+36),fill='#526371',width=2)
 d.rectangle((530,140,548,800),fill='#273440');d.ellipse((840,200,948,308),fill='#131b28',outline='#9b7270',width=3)
 ang=t*.9;d.line((894,254,894+35*math.sin(ang),254-35*math.cos(ang)),fill=WHITE,width=3);d.line((894,254,914,267),fill=RED,width=3)
 d.rectangle((0,1040,1080,1120),fill='#47343a');d.rectangle((0,1040,1080,1055),fill='#75504c')
 # Character types, nods, and follows the screen cursor.
 breathe=math.sin(t*2.5)*3;d.rounded_rectangle((80,785+breathe,410,1180),radius=90,fill='#263248')
 head(im,245,663,96,t,energy(t)*.15)
 d=ImageDraw.Draw(im);wrist=(480+math.sin(t*17)*7,1015-abs(math.sin(t*15))*10)
 bone(d,(330,861),(350,960),65,'#243045');bone(d,(350,960),wrist,43,SKIN);ell(d,(wrist[0]-22,wrist[1]-14,wrist[0]+35,wrist[1]+12),SKIN)
 # Monitor: real shape changes, drawing, cursor movements and corrected layout.
 d.rounded_rectangle((444,573,1008,945),radius=20,fill='#0b121d',outline='#506470',width=5)
 d.rounded_rectangle((463,593,989,920),radius=8,fill='#172b39');d.rectangle((463,593,989,626),fill='#233c4c')
 for j,col in enumerate([RED,'#e0b169','#8fbdac']):ell(d,(478+j*19,604,487+j*19,613),col)
 d.rectangle((478,645,570,901),fill='#203746')
 for j in range(5):d.rounded_rectangle((490,660+j*36,554,671+j*36),radius=4,fill='#476473')
 progress=ease((local-.1)/1.4)
 if adjust:
  shift=120*(1-ease(local/1.0));d.rounded_rectangle((592+shift,655,940,733),radius=8,fill='#263f4b',outline=RED,width=3)
  d.rounded_rectangle((592,756,940,891),radius=8,fill='#223e4a',outline='#7ea8af',width=2)
  if local>1.1:
   d.line([(887,691),(899,703),(921,675)],fill='#b7d7c5',width=6)
 else:
  d.rounded_rectangle((592,647,966,720),radius=7,fill='#39535e')
  for j in range(3):
   width=310*max(0,min(1,(progress-j*.18)*1.5));y=748+j*48
   d.rounded_rectangle((595,y,595+max(1,width),y+17),radius=5,fill=TEAL if j!=2 else RED)
  d.rounded_rectangle((594,892,594+int(370*progress),900),radius=3,fill='#94b4a6')
 cx=700+120*math.sin(local*2);cy=700+60*math.cos(local*2)
 if adjust:cx=880;cy=685
 d.polygon([(cx,cy),(cx+2,cy+25),(cx+9,cy+18),(cx+20,cy+17)],fill=WHITE)
 d.polygon([(675,950),(784,950),(807,1040),(648,1040)],fill='#263441');d.rounded_rectangle((440,1001,843,1035),radius=9,fill='#16212d')
 for row in range(3):
  for col in range(12):d.rounded_rectangle((452+col*30,1006+row*8,475+col*30,1010+row*8),radius=2,fill='#3a4a59')
 # Lamp and notebook.
 bone(d,(1035,1040),(1031,882),10,'#604b49');d.polygon([(988,845),(1064,845),(1080,900),(960,900)],fill='#7f3b3f');d.line((971,899,1078,899),fill='#d8a673',width=5);d.rectangle((850,1020,980,1038),fill='#b89b80')
 return im

def runner(t,local):
 im=BASE.copy();d=ImageDraw.Draw(im);horizon=470
 # Parallax city and perspective road move continuously behind the rig.
 d.rectangle((0,0,W,horizon+150),fill='#293242');d.ellipse((700,340,960,600),fill='#b97760')
 for layer,scale,color in [(0,.45,'#293647'),(1,.8,'#192737')]:
  for i in range(-2,10):
   x=(i*170-t*34*scale)%1420-180;bh=180+(i*127+layer*93)%260;d.rectangle((x,horizon-bh,x+135,horizon+180),fill=color)
   for row in range(3):
    for col in range(3):d.rectangle((x+20+col*35,horizon-bh+24+row*48,x+31+col*35,horizon-bh+42+row*48),fill='#4e5558')
 d.polygon([(390,horizon),(690,horizon),(1190,1370),(-110,1370)],fill='#1c2632')
 for i in range(12):
  z=((i/12+t*.36)%1);y=horizon+(z*z)*1000;wide=2+z*10
  d.line((540,y,540,y+15+z*80),fill='#727879',width=int(wide))
  d.line((390-z*400,y,405-z*400,y),fill='#394b5b',width=3)
 # Articulated running figure: opposite shoulder/hip phases, bent knees and foot roll.
 phase=t*11;bob=abs(math.sin(phase))*13;hip=np.array([540.,800.+bob]);should=np.array([566.,585.+bob])
 d.ellipse((390,1130,740,1170),fill='#0c151f')
 for side in [-1,1]:
  a=math.sin(phase+(.0 if side<0 else math.pi));knee=hip+np.array([a*102,128-abs(a)*34]);foot=knee+np.array([-a*126,143-abs(a)*70])
  bone(d,tuple(hip),tuple(knee),56,'#35475c' if side<0 else '#24374b');bone(d,tuple(knee),tuple(foot),37,'#a87560' if side<0 else SKIN)
  bone(d,(foot[0]-12,foot[1]+4),(foot[0]+49,foot[1]+15),28,'#101a27');d.line((foot[0]-18,foot[1]+24,foot[0]+59,foot[1]+24),fill=RED,width=5)
 d.polygon([(should[0]-47,should[1]),(should[0]+45,should[1]+10),(hip[0]+47,hip[1]+15),(hip[0]-53,hip[1])],fill='#202f43')
 for side in [-1,1]:
  swing=math.sin(phase+(math.pi if side<0 else 0));elbow=should+np.array([swing*110,95]);hand=elbow+np.array([swing*70,-85+swing*20])
  bone(d,tuple(should),tuple(elbow),38,'#a87560' if side<0 else SKIN);bone(d,tuple(elbow),tuple(hand),30,SKIN)
 head(im,578,492+bob,66,t,0)
 # Direction route draws on, then holds. No numeric promise or invented metric.
 d=ImageDraw.Draw(im);p=ease(local/.8);x0,y0=140,1160;x1,y1=900,1060;d.line((x0,y0,x0+(x1-x0)*p,y0+(y1-y0)*p),fill=RED,width=6)
 if p>.95:d.line((860,1040,900,1060,866,1094),fill=RED,width=6)
 return im

LINES=[['EU NÃO PRECISO','IMPRESSIONAR','TODO MUNDO.'],['PRECISO ME ORGULHAR','DO QUE EU','ENTREGO.'],['ENQUANTO BUSCAM','APLAUSOS, EU ESCOLHO','UMA DIREÇÃO.'],['FAÇO O QUE','PRECISA SER FEITO.'],['AJUSTO O QUE','NÃO FUNCIONA.'],['E REPITO.'],['ATÉ O MEU TRABALHO','FALAR','POR MIM.']]
TEXTCACHE={}
def captions(im,i,local,t):
 d=ImageDraw.Draw(im);lines=LINES[i];top=1370 if len(lines)==3 else 1420
 if len(lines)==1:top=1450
 for j,line in enumerate(lines):
  offset=j*.29;vis=ease((local-offset)/.18)
  if vis<=0:continue
  size=92 if len(lines)>1 else 138
  while font(size).getlength(line)>900:size-=2
  key=(line,size,j==len(lines)-1)
  if key not in TEXTCACHE:
   f=font(size);bbox=f.getbbox(line);layer=Image.new('RGBA',(1000,180));ld=ImageDraw.Draw(layer);ld.text((500,85),line,font=f,anchor='mm',fill=RED if key[2] else WHITE,stroke_width=2,stroke_fill='#090e16');TEXTCACHE[key]=layer
  lay=TEXTCACHE[key].copy();lay.putalpha(lay.getchannel('A').point(lambda a:int(a*vis)));im.paste(lay,(40,int(top+j*109-85+(1-vis)*22)),lay)
 # Accent moves with the final stressed line.
 if local>.4:
  length=int(84*ease((local-.4)/.3));d.line((540-length//2,top+len(lines)*109+6,540+length//2,top+len(lines)*109+6),fill=RED,width=5)
 return im

def scene_index(t):return max(i for i,s in enumerate(SC) if t>=s['start'])
def illustration(t,i):
 s=SC[i];local=t-s['start'];typ=s['visual']
 if typ in ['distracoes','repeticao','final']:return podcast(t,local)
 if typ in ['trabalho','ajuste']:return work(t,local,typ=='ajuste')
 return runner(t,local)
def frame(t):
 i=scene_index(t);s=SC[i];local=t-s['start'];im=illustration(t,i)
 if i and local<.10:im=Image.blend(illustration(s['start']-.001,i-1),im,ease(local/.1))
 im=Image.alpha_composite(im.convert('RGBA'),VEIL).convert('RGB')
 if i==6:
  fade=ease((t-(D-1.1))/.7)
  if fade:im=Image.blend(im,Image.new('RGB',(W,H),INK),fade*.95)
 im=captions(im,i,local,t)
 if t>D-.18:im=Image.blend(im,Image.new('RGB',(W,H),INK),ease((t-D+.18)/.18))
 return im

if __name__=='__main__':
 if '--frames' in sys.argv:
  for i,s in enumerate(SC):frame(s['start']+min(1,s['duration']*.6)).save(P/f'qc/cena-{i}.png')
  print('frames ready');raise SystemExit()
 end=3 if '--test' in sys.argv else D;out=P/('build/test-animacao.mp4' if '--test' in sys.argv else 'build/animacao-muda.mp4')
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for n in range(math.ceil(end*FPS)):
  p.stdin.write(frame(n/FPS).tobytes())
  if n%60==0:print(f'{n/FPS:.1f}/{end:.1f}s',flush=True)
 p.stdin.close();assert p.wait()==0
 print('READY',out)
