from pathlib import Path
import json,subprocess,sys,numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parents[1];V=Path('/workspace/output/animacao-com-voz.mp4');m=json.loads((P/'manifest.json').read_text())
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True)
d=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(V)]).stdout);v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio');duration=float(d['format']['duration'])
assert abs(duration-m['duration'])<m['duration']*.01
assert (v['width'],v['height'],v['codec_name'],v['pix_fmt'])==(1080,1920,'h264','yuv420p');assert a['sample_rate']=='48000' and a['channels']==2
r=run(['ffmpeg','-hide_banner','-i',str(V),'-vf','blackdetect=d=1:pix_th=0.05','-af','silencedetect=n=-50dB:d=3,loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json','-f','null','-']);(P/'qc/controle.log').write_text(r.stderr)
assert 'silence_start:' not in r.stderr;assert 'black_start:' not in r.stderr
sys.path.insert(0,'/workspace/videos-virais-/.agents/skills/video-viral');import desmontar as kit
frames=[];times=[s['start']+min(1,s['duration']*.6) for s in m['scenes']]
for t in times:frames.append(kit.quadro(V,t,270))
kit.folha(frames,[f'{t:.1f}s' for t in times],4,P/'qc/conferencia.jpg')
# Verify that the character/object area changes inside a shot, independent of text.
motion=[]
for i in [0,1,2,4]:
 start=m['scenes'][i]['start'];f1=kit.quadro(V,start+.6,270);f2=kit.quadro(V,start+1.0,270);ar=np.asarray(f1)[60:285];br=np.asarray(f2)[60:285];changed=float((np.max(np.abs(ar.astype(float)-br.astype(float)),axis=2)>12).mean());motion.append({'scene':i,'changed_fraction':changed});assert changed>.005
report={'duration_s':duration,'resolution':[1080,1920],'fps':v['r_frame_rate'],'audio':{'codec':a['codec_name'],'sample_rate':48000,'channels':2,'integrated_lufs':kit.volume(V),'voice':'Kokoro pm_alex pt-br'},'decode_ok':True,'unexpected_silence':False,'black_frames_over_one_second':False,'motion_inside_scenes':motion,'animation':'Articulated 2D, original drawn assets, mouth driven by speech amplitude; no phoneme-accurate lip sync','tts_generation':'Local Kokoro, separate from VoiceStudio API','file_bytes':int(d['format']['size'])}
(P/'qc/report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));m['status']='validated';(P/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False));Path('/workspace/output/animacao-manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False))
