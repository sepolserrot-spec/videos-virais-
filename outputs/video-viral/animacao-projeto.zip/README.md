# O trabalho fala por mim — animação 2D

Personagens, objetos e cenários desenhados e animados em Python/Pillow. Sem sequência de fotografias.
Narração local em português brasileiro: Kokoro ONNX, voz pm_alex. O runtime é MIT e o modelo é Apache-2.0, conforme a documentação oficial https://github.com/thewh1teagle/kokoro-onnx . Essa voz é executada separadamente do VoiceStudio.

O VoiceStudio 0.5.7 está instalado em /workspace/voicestudio e a API /health foi verificada em CPU. A voz deste vídeo não foi sintetizada pela API do VoiceStudio.

Reproduzir neste ambiente:
1. /workspace/tts-kokoro/.venv/bin/python scripts/narrar.py
2. python scripts/animar.py --test
3. python scripts/animar.py
4. python scripts/finalizar.py
5. python scripts/verificar.py

Os modelos Kokoro ficam fora do pacote, em /workspace/tts-kokoro/models. Não baixar novamente quando os arquivos já estiverem instalados. scripts/narrar.py reutiliza os WAVs existentes.

manifest.json conserva as frases, os tempos de narração e o estado de validação. O movimento da boca segue a amplitude da fala; não é sincronização fonética precisa.
A referência orientou o gancho, as trocas entre locutor e cenas de apoio e o texto branco/vermelho. Não foi reutilizado rosto, fala ou música do original. A trilha instrumental é original.
